// SPDX-License-Identifier: MIT
#include "cubic_optimizer.hpp"
#include "support_barrier.hpp"
#include <cassert>
#include <iostream>
using namespace gcopter::direct;
using namespace gcopter::direct::native;

static void checkProofs(const CubicProblem::Group& group,double offset,double radius) {
  auto find=[&](int id)->const CubicProblem::Support& {
    const auto p=std::find_if(group.supports.begin(),group.supports.end(),
                            [&](const auto& s){return s.original_id==id;});
    assert(p!=group.supports.end());return *p;
  };
  auto dual=[&](int id) {
    if(id<0)return Vec3::Zero().eval();
    const auto& p=find(id);return Vec3(p.normal/(p.bound-p.normal.dot(group.proof_center)));
  };
  for(const auto& proof:group.proofs) {
    assert(find(proof.removed).redundant);
    if(proof.left>=0)assert(!find(proof.left).redundant);
    if(proof.right>=0)assert(!find(proof.right).redundant);
    assert(proof.left_weight>=0&&proof.right_weight>=0&&proof.left_weight+proof.right_weight<=1);
    const Vec3 residual=dual(proof.removed)-proof.left_weight*dual(proof.left)-proof.right_weight*dual(proof.right);
    long double upper=proof.left_weight+proof.right_weight;
    upper+=residual.cast<long double>().dot((group.reference.head<3>()-group.proof_center).cast<long double>());
    for(int k=0;k<group.count;++k)
      upper+=(offset+radius)*(group.maps[k].cast<long double>().transpose()*residual.cast<long double>()).norm();
    assert(upper<1-1e-11);
    assert(std::abs(upper-proof.upper)<1e-11);
  }
}

int main() {
  for(const Vec3 y:{Vec3(0,0,0),Vec3(.2,.1,.3),Vec3(.2,1e-10,-2e-10)}) {
    auto jet=[&](const Vec3& p,Vec3& g,Eigen::Matrix3d& h) {
      const Vec3 v(1-p[0],p[1],p[2]);const double r=supportRadius(v),gap=v[0]-r;
      distanceBarrierJet(v,.003,r,gap,g,h);return -.003*std::log(gap);
    };
    Vec3 g;Eigen::Matrix3d h;jet(y,g,h);
    assert(g.allFinite()&&h.allFinite());
    for(int axis=0;axis<3;++axis) {
      const double step=axis>0&&y.tail<2>().norm()<1e-8?1e-13:1e-6;
      const Vec3 d=Vec3::Unit(axis);Vec3 gp,gm;Eigen::Matrix3d unused;
      jet(y+step*d,gp,unused);jet(y-step*d,gm,unused);
      assert(((gp-gm)/(2*step)-h.col(axis)).norm()<1e-6*std::max(1.,h.col(axis).norm()));
    }
  }
  for(double tilt:{0.,1e-9,.05,.5})for(bool one_sided:{false,true}) {
    CubicProblem::Group group;group.first=0;group.count=2;group.reference.setZero();
    group.maps[0].col(0)=.5*Vec3::UnitY();group.maps[0].col(1)=.5*Vec3::UnitZ();
    group.maps[1].col(0)=.5*Vec3(std::sin(tilt),std::cos(tilt),0);
    group.maps[1].col(1)=.5*Vec3::UnitZ();
    Eigen::VectorXd initial=Eigen::VectorXd::Zero(10);
    for(int i=0;i<2;++i){initial[5*i+2]=.15;initial[5*i+4]=.15;}
    auto add=[&](Vec3 n,double b){group.supports.push_back({n,b,true,false,int(group.supports.size())});};
    for(int j=0;j<4;++j) {
      const double theta=(one_sided?j*.35:j*1.5707963267948966);
      add(Vec3(0,std::cos(theta),std::sin(theta)),1.);
    }
    for(int j=0;j<12;++j) {
      const double theta=(one_sided?j*.08:j*.5235987755982988);
      add(Vec3(0,std::cos(theta),std::sin(theta)),2.);
    }
    add(Vec3(0,1,1e-12),1.+1e-11); // Nearly parallel, nearly tight.
    add(Vec3(1,.1,.1),.1); // A 2-D projection alone cannot justify deleting this.
    pruneProjectedSupports(group,initial,1.,1.);
    assert(group.proofs.size()>=6);checkProofs(group,1.,1.);
    int feasible=0;
    for(int trial=0;trial<400;++trial) {
      Eigen::VectorXd x(10);
      for(int i=0;i<2;++i) {
        const double a=.17*(trial+1)*(i+1),b=.31*(trial+2)*(i+1);
        x.segment<2>(5*i)<<.7*std::sin(a),.7*std::cos(a);
        Eigen::Matrix2d rotation;rotation<<std::cos(b),-std::sin(b),std::sin(b),std::cos(b);
        const Eigen::Matrix2d shape=rotation*Eigen::Vector2d(.15,.8).asDiagonal()*rotation.transpose();
        x.segment<3>(5*i+2)<<shape(0,0),shape(0,1),shape(1,1);
      }
      const auto y=group.geometry(x);bool safe=true;
      auto value=[&](const auto& p) {
        return p.normal.dot(y.head<3>())+std::hypot(p.normal.dot(y.segment<3>(3)),p.normal.dot(y.tail<3>()))-p.bound;
      };
      for(const auto& p:group.supports)if(!p.redundant&&value(p)>0)safe=false;
      if(safe){++feasible;for(const auto& p:group.supports)assert(value(p)<1e-10);}
    }
    assert(feasible>0);
  }

  auto model=CubicModel::fromSeed({Vec3(-2,0,0),Vec3(2,0,0)},.5,.2,1.5);
  Options options;options.max_offset=2;options.max_radius=3;
  std::vector<detail::SupportPlane> planes;
  for(int span=0;span<int(model.basis.spans.size());++span) {
    for(int axis:{1,2})for(double sign:{-1.,1.})planes.push_back({span,0,1,sign*Vec3::Unit(axis),1.});
    for(int j=0;j<12;++j) {
      const double a=j*.5235987755982988;
      planes.push_back({span,0,1,Vec3(0,std::cos(a),std::sin(a)),1.7});
    }
  }
  for(bool distance:{false,true}) {
  OptimizerSettings settings;settings.tensor_assembly=false;settings.distance_barrier=distance;
  CubicProblem original(model,planes,4.,options,settings);
  settings.projected_pruning=1;CubicProblem assembly(model,planes,4.,options,settings);
  settings.projected_pruning=2;CubicProblem complete(model,planes,4.,options,settings);
  settings.reference_assembly=true;CubicProblem dense(model,planes,4.,options,settings);
  for(const auto& group:complete.groups){assert(group.boundary_count<group.supports.size());checkProofs(group,2.,3.);}
  Eigen::VectorXd ga,gb;BandedSPD ha,hb;
  const double fa=complete.objective(model.x,.003,&ga,&ha),fb=dense.objective(model.x,.003,&gb,&hb);
  assert(std::abs(fa-fb)<1e-12);assert((ga-gb).norm()<1e-11);assert((ha.data-hb.data).norm()<1e-10);
  OptimizerMetrics metrics;complete.checkDerivatives(model.x,metrics);
  assert(metrics.gradient_error<1e-7&&metrics.hessian_error<1e-7);
  for(int trial=0;trial<32;++trial) {
    Eigen::VectorXd direction(model.x.size());
    for(int j=0;j<direction.size();++j)direction[j]=3*std::sin((j+1)*(trial+1)*.193);
    const auto a=assembly.prepareLine(model.x,direction,.003),b=complete.prepareLine(model.x,direction,.003);
    assert(std::abs(a.step-b.step)<1e-12);
    assert(std::abs(b.step-complete.feasibleStep(model.x,direction))<1e-12);
    assert(std::isfinite(original.objective(model.x+b.step*direction,.003)));
    CubicProblem::Evaluation values;complete.objective(model.x,.003,nullptr,nullptr,&values);
    const auto cached=complete.prepareLine(model.x,direction,.003,&values);
    assert(cached.step==b.step);
    for(double fraction:{.1,.5,1.}) {
      const double alpha=b.step*fraction;
      const double actual=complete.objective(model.x+alpha*direction,.003)-fa;
      assert(std::abs(b.delta(alpha)-actual)<1e-10*std::max(1.,std::abs(actual)));
      assert(cached.delta(alpha)==b.delta(alpha));
    }
  }
  }
  std::cout<<"projected proofs retain witnesses; original constraints, derivatives and line bounds verified\n";
}
