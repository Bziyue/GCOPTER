#!/usr/bin/env python3
"""Build experiments against a private source snapshot; no production switches."""
import argparse,fcntl,hashlib,json,os,resource,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',default='.scratch/inflation');p.add_argument('--targets',default='benchmark,measure,tests');a=p.parse_args()
repo=Path(__file__).resolve().parents[3];here=Path(__file__).resolve().parent
out=(repo/a.output).resolve();out.mkdir(parents=True,exist_ok=True)
lock=(out/'build.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX)
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
snapshot=out/'include';shutil.copytree(repo/'SweepCorridor/include',snapshot,dirs_exist_ok=True)
detail=snapshot/'SweepCorridor/detail'
source_hashes={str(f.relative_to(repo)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'SweepCorridor/include').rglob('*.hpp')}
for name in ('Experiment.hpp','ExperimentConfig.hpp','AreaObjective.hpp'):shutil.copy2(here/name,detail/name)
def edit(name,old,new):
    f=detail/name;s=f.read_text();assert s.count(old)==1,(name,old);f.write_text(s.replace(old,new))
edit('CubicGeneratorImpl.hpp','#include "ObstacleCover.hpp"','#include "Experiment.hpp"\n#include "ObstacleCover.hpp"')
edit('CubicGeneratorImpl.hpp','CubicModel::fromSeed(seed,std::ldexp(o.control_spacing,-refinement),o.min_radius*1.1,o.frame_smoothing);',
     'CubicModel::fromSeed(seed,std::ldexp(o.control_spacing,-refinement),o.min_radius*1.1,o.frame_smoothing,experiment::breaks(refinement));')
edit('CubicOptimizer.hpp','struct CubicEnergy {','struct AreaProbe { int first; double weight; Eigen::Matrix<double,3,12> map; };\nstruct CubicEnergy {\n  std::vector<AreaProbe> area;')
edit('CubicOptimizerImpl.hpp','#include "CubicOptimizer.hpp"','#include "CubicOptimizer.hpp"\n#include "AreaObjective.hpp"')
edit('CubicOptimizerImpl.hpp','  // Exact two-point Gauss integration of squared cubic second derivatives.',
     '  if(experiment::config.sample_area)area=experiment::makeAreaProbes(m);\n  // Exact two-point Gauss integration of squared cubic second derivatives.')
edit('CubicOptimizerImpl.hpp','  auto logdet=[&](int i,const Eigen::Matrix2d& p,double weight,double sign) {',
     '  if(experiment::config.sample_area){const double area=experiment::areaObjective(*this,x,g,h,evaluate_cost);if(!std::isfinite(area))return INFINITY;cost+=area;}\n  auto logdet=[&](int i,const Eigen::Matrix2d& p,double weight,double sign) {')
edit('CubicOptimizerImpl.hpp','if(!logdet(i,s,model.basis.weight(i),1)',
     'if(!logdet(i,s,experiment::config.sample_area?0:model.basis.weight(i),1)')
edit('CubicOptimizerImpl.hpp','        barrier_gradient=(g-primary)/mu;',
     '        if(experiment::config.sample_area)objective(x,0,&primary,nullptr,false);\n        barrier_gradient=(g-primary)/mu;')
edit('CubicRefinement.hpp','    spd(s,d,model.basis.weight(i),false);','    spd(s,d,experiment::config.sample_area?0:model.basis.weight(i),false);')
edit('CubicRefinement.hpp','    if(constrain)boundary(a,b,c,s(0,0),d(0,0));\n  };',
     '    if(constrain)boundary(a,b,c,s(0,0),d(0,0));\n  };\n  if(experiment::config.sample_area)experiment::areaShapes(*energy,x,direction,[&](const M2& a,const M2& d,double w){spd(a,d,w,true);});')
edit('CubicOptimizerImpl.hpp','  for(int i=0;i<model.basis.count;++i) {\n    const auto s=matrix(x,i),d=matrix(step,i);',
     '  if(experiment::config.sample_area)experiment::areaShapes(*energy,x,step,[&](const Eigen::Matrix2d& a,const Eigen::Matrix2d& d,double){spd(a,d);});\n  for(int i=0;i<model.basis.count;++i) {\n    const auto s=matrix(x,i),d=matrix(step,i);')
edit('CubicMetrics.hpp','static constexpr int iterations=8,corrector_iterations=3,inflation_iterations=2;','int iterations=8,corrector_iterations=3,inflation_iterations=2;')
edit('CubicGeneratorImpl.hpp','iteration<OptimizerSettings::inflation_iterations','iteration<solver.inflation_iterations')
edit('CubicGeneratorImpl.hpp','auto candidate=model.x;','auto candidate=model.x;\n        if(iteration==0)experiment::inflate(problem,candidate);')
edit('CubicGeneratorImpl.hpp','if(iteration+1==OptimizerSettings::inflation_iterations)\n          problem.refineVolume(model.x,result.optimizer,[&](const Eigen::VectorXd& x){deadline.check();return certify(model.geometry(x),cover).safe();});',
     'if(iteration+1==solver.inflation_iterations) {\n          auto check=[&](const Eigen::VectorXd& x){deadline.check();return certify(model.geometry(x),cover).safe();};\n          problem.refineVolume(model.x,result.optimizer,check);\n          experiment::refine(problem,model.x,check);\n        }')
edit('ObstacleCover.hpp','std::max(.5 * (c[D] - c[0]).norm(), options.min_radius);','experiment::longitudinal<D>(c,m,options.min_radius);')
edit('ObstacleCover.hpp','    spans.resize(breaks.size()-1);',
     '    if(experiment::limit_end_boxes&&!boxes.empty()){boxes.front().bounds=experiment::endpoint_boxes[0];boxes.back().bounds=experiment::endpoint_boxes[1];}\n    spans.resize(breaks.size()-1);')
commands=[]
for name in a.targets.split(','):
    assert name in ('benchmark','measure','tests')
    command=['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(snapshot),'-I/usr/include/eigen3',str(here/(name+'.cpp')),'-o',str(out/name)]
    if name=='tests':command.append('-UNDEBUG')
    commands.append(command)
    with (out/(name+'_build.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
(out/'build.json').write_text(json.dumps(dict(source_hashes=source_hashes,experiment_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in here.iterdir() if f.is_file()},commands=commands,compiler=subprocess.check_output(['c++','--version'],text=True).splitlines()[0]),indent=2)+'\n')
print(out,flush=True)
