#pragma once
#include <vector>
#include "Types.hpp"
namespace SweepCorridor::internal::cubic::experiment {
struct Config { int local_steps=0,volume_passes=0; double metric_length=0; bool sample_area=false; };
struct Stats { int local_steps=0,local_blocks=0,volume_accepts=0; double local_ms=0,volume_ms=0; };
inline Config config;
inline Stats stats;
inline std::vector<double> requested_breaks;
inline bool limit_end_boxes=false;
inline Bounds endpoint_boxes[2];
inline std::vector<double> breaks(int refinement) {
  if(refinement==0||requested_breaks.empty())return requested_breaks;
  const int parts=1<<refinement;std::vector<double> out;out.reserve((requested_breaks.size()-1)*parts+1);out.push_back(0);
  for(size_t i=1;i<requested_breaks.size();++i)for(int j=1;j<=parts;++j)
    out.push_back(requested_breaks[i-1]+(requested_breaks[i]-requested_breaks[i-1])*j/parts);
  return out;
}
}
