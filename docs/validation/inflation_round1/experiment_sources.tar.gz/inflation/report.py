#!/usr/bin/env python3
"""Create the research report, compact CSV, and geometry/metric figures."""
import argparse,csv,itertools,json,os,resource,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--development',default='.scratch/inflation/final');p.add_argument('--selection',default='.scratch/inflation/selection');p.add_argument('--holdout',default='.scratch/inflation/holdout_bounded');p.add_argument('--output',default='docs/validation/inflation_round1');a=p.parse_args()
repo=Path(__file__).resolve().parents[3];os.chdir(repo);resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection,LineCollection
from matplotlib.font_manager import FontProperties
out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
dev=json.loads((Path(a.development)/'summary.json').read_text());hold=json.loads((Path(a.holdout)/'summary.json').read_text())
selected=json.loads((Path(a.selection)/'summary.json').read_text());sbases={r['case']:r for r in selected if r['mode']=='baseline'}
firi={r['case']:r for r in json.loads((Path(a.selection)/'firi_summary.json').read_text())}
bases={r['case']:r for r in dev if r['mode']=='baseline'}
labels={'baseline':'当前 C3','caps':'延长路径重生成','append':'固定原曲面追加','local_budget':'局部条件椭圆膨胀','metric_short':'0.5 m 分离面尺度','metric':'1.0 m 分离面尺度','volume':'额外局部体积修正','area':'截面投影面积目标','area_metric_caps':'截面积＋尺度＋端部','area_append':'截面积＋局部追加','metric_caps':'尺度＋端部','caps_aligned':'保留原节点的端部延伸','caps_aligned_budget':'对齐节点、固定 7 步','caps_balanced':'对齐节点、工作量预算'}
labels.update(caps_aligned_bounded='节点对齐、完整迭代',caps_balanced_bounded='节点对齐、预算平衡')
def gain(r):return 100*r['union']['paired_delta']/r['union']['baseline']
def stat(rows,baseline):
    good=[r for r in rows if r['success'] and baseline[r['case']]['success']]
    dt=[100*(r['median_ms']/baseline[r['case']]['median_ms']-1) for r in good]
    dv=[gain(r) for r in good if 'union' in r]
    db=[100*(r['boundary_bending']/baseline[r['case']]['boundary_bending']-1) for r in good if baseline[r['case']]['boundary_bending']>1e-12]
    return dict(success=sum(r['success'] for r in rows),count=len(rows),time=statistics.median(dt),volume=statistics.median(dv) if dv else 0,
                min_volume=min(dv) if dv else 0,max_volume=max(dv) if dv else 0,bending=statistics.median(db),rss=max(r['max_rss_kib'] for r in rows)/1024)
table=[]
for mode in dict.fromkeys(r['mode'] for r in dev):
    if mode=='baseline':continue
    rows=[r for r in dev if r['mode']==mode];s=stat(rows,bases)
    table.append(f"| {labels[mode]} | {s['time']:+.2f}% | {s['volume']:+.2f}% | {s['min_volume']:+.2f}%～{s['max_volume']:+.2f}% | {s['bending']:+.1f}% |")
hb={r['case']:r for r in hold if r['mode']=='baseline'};hold_table=[]
for mode in ('caps_aligned_bounded','caps_balanced_bounded'):
    rows=[r for r in hold if r['mode']==mode];s=stat(rows,hb)
    less=[r['case'] for r in rows if r['success'] and hb[r['case']]['success'] and r.get('union',{}).get('paired_delta',0)<-r.get('union',{}).get('paired_ci95',0)]
    hold_table.append(f"| {labels[mode]} | {s['success']}/{s['count']} | {s['time']:+.2f}% | {s['volume']:+.2f}% | {s['min_volume']:+.2f}%～{s['max_volume']:+.2f}% | {s['bending']:+.1f}% | {less} |")
with (out/'comparison.csv').open('w') as file:
    writer=csv.writer(file);writer.writerow(['split','case','family','mode','success','median_ms','p95_ms','union_m3','union_delta_percent','paired_ci95_m3','core_delta_percent','boundary_bending','prefix_m','suffix_m','max_rss_kib'])
    for split,rows in [('development',dev),('selection',selected),('holdout',hold)]:
        for r in rows:
            v=r.get('union',{});c=r.get('core_union',{})
            writer.writerow([split,r['case'],r['family'],r['mode'],r['success'],r['median_ms'],r['p95_ms'],v.get('candidate',''),gain(r) if v else '',v.get('paired_ci95',''),100*c['paired_delta']/c['baseline'] if c else '',r.get('boundary_bending',''),r.get('prefix',''),r.get('suffix',''),r['max_rss_kib']])
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'font.size':10})
fig,axes=plt.subplots(1,2,figsize=(11,4.2))
case_ids=list(sbases);x=np.arange(len(case_ids));modes=['caps_aligned_bounded','caps_balanced_bounded'];colors=['#c4515d','#148369']
for mode,color,shift in zip(modes,colors,[-.18,.18]):
    rows=[next(r for r in selected if r['case']==case and r['mode']==mode) for case in case_ids]
    axes[0].bar(x+shift,[gain(r) for r in rows],width=.34,color=color,label=labels[mode],
                yerr=[100*r['union']['paired_ci95']/r['union']['baseline'] for r in rows],capsize=2)
    axes[1].bar(x+shift,[100*(r['median_ms']/sbases[r['case']]['median_ms']-1) for r in rows],width=.34,color=color)
for ax,title in zip(axes,['三维并集体积变化 / %','完整生成耗时变化 / %']):
    ax.axhline(0,color='#687789',lw=.8);ax.set_xticks(x,[str(v) for v in case_ids]);ax.set_xlabel('冻结案例编号');ax.set_title(title);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=2,frameon=False);fig.tight_layout(rect=(0,.1,1,1));fig.savefig(out/'paired_metrics.png',dpi=160);plt.close(fig)

def hull(points):
    points=sorted(set(map(tuple,np.round(points,9))))
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower=[];upper=[]
    for p in points:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return np.array(lower[:-1]+upper[:-1])
def firi_outlines(path):
    data=np.loadtxt(path,delimiter=',',skiprows=1);lines=[]
    for i in np.unique(data[:,0]):
        h=data[data[:,0]==i,1:];vertices=[]
        for ids in itertools.combinations(range(len(h)),3):
            selected=h[list(ids)];mat=selected[:,:3]
            if abs(np.linalg.det(mat))<1e-9:continue
            point=np.linalg.solve(mat,-selected[:,3])
            if np.all(h[:,:3]@point+h[:,3]<=1e-7):vertices.append(point[:2])
        poly=hull(vertices)
        if len(poly):lines.append(np.vstack([poly,poly[0]]))
    return lines
def surface(path):
    cp=np.loadtxt(path,delimiter=',',skiprows=1).reshape(-1,4,12);t=np.linspace(0,1,9);w=np.array([(1-t)**3,3*t*(1-t)**2,3*t*t*(1-t),t**3]).T
    y=np.concatenate([w@p[:,3:] for p in cp]);centers=y[:,:3];m=y[:,3:].reshape(-1,2,3).transpose(0,2,1)
    angle=np.linspace(0,2*np.pi,33);circle=np.array([np.cos(angle),np.sin(angle)])
    rings=centers[:,:,None]+m@circle
    quads=np.stack([rings[:-1,:2,:-1].transpose(0,2,1),rings[1:,:2,:-1].transpose(0,2,1),rings[1:,:2,1:].transpose(0,2,1),rings[:-1,:2,1:].transpose(0,2,1)],axis=2).reshape(-1,4,2)
    return quads,centers
manifest=json.loads((Path(a.selection)/'manifest.json').read_text());case=next(c for c in manifest['cases'] if c['case']==67)
cloud=np.loadtxt(case['map']);seed=np.loadtxt(case['seed']);wire=firi_outlines(Path(a.selection)/'case_67/firi/firi_planes.csv')
fig,axs=plt.subplots(1,3,figsize=(15,6));view_modes=['baseline','caps_aligned_bounded','caps_balanced_bounded']
lo=seed[:,:2].min(axis=0)-5;hi=seed[:,:2].max(axis=0)+5
for ax,mode,face,line in zip(axs,view_modes,['#efc0c6','#b5dace','#b5dace'],['#a52e43','#116b55','#116b55']):
    r=next(r for r in selected if r['case']==67 and r['mode']==mode);quads,centers=surface(Path(r['output'])/'corridor.csv')
    ax.scatter(cloud[::16,0],cloud[::16,1],s=2,color='#dde3eb',linewidths=0,rasterized=True)
    ax.add_collection(PolyCollection(quads,facecolors=face,edgecolors='none',rasterized=True))
    ax.add_collection(LineCollection(wire,colors='#3265a0',linewidths=.65,alpha=.8))
    ax.plot(centers[:,0],centers[:,1],color=line,lw=1)
    ax.scatter(seed[[0,-1],0],seed[[0,-1],1],c='#202d3c',s=23,zorder=5)
    for pt,label in zip(seed[[0,-1]],['S','G']):ax.annotate(label,pt[:2],xytext=(5,4),textcoords='offset points',fontsize=11)
    ax.set_title(f"{labels[mode]}\n{r['median_ms']:.2f} ms"+(f"，并集体积 {gain(r):+.2f}%" if mode!='baseline' else ''))
    ax.set_xlim(lo[0],hi[0]);ax.set_ylim(lo[1],hi[1]);ax.set_aspect('equal');ax.set_xlabel('x / m');ax.set_ylabel('y / m');ax.grid(alpha=.15)
fig.suptitle('同一地图与原始路径：蓝线为 FIRI，多边形填色为 C3 俯视投影',fontsize=14)
fig.text(.5,.02,'S / G 为原点击位置；延伸后位于走廊内部。俯视图仅比较外形，体积由三维配对采样计算。',ha='center')
fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(out/'same_input_corridors.png',dpi=170);plt.close(fig)
latest={r['mode']:r for r in selected if r['case']==67};latest_table=[]
for mode in ('baseline','caps_aligned_bounded','caps_balanced_bounded'):
    r=latest[mode];vol=r['union']['candidate'] if mode!='baseline' else latest['caps_balanced_bounded']['union']['baseline']
    latest_table.append(f"| {labels[mode]} | {r['median_ms']:.2f} | {vol:.2f} | {r['boundary_bending']:.2f} |")
latest_table.append(f"| FIRI | {firi[67]['firi_median_ms']:.2f} | {firi[67]['firi_union_m3']:.2f} | — |")
core_table=[]
for mode in ('caps_aligned_bounded','caps_balanced_bounded'):
    r=latest[mode];v=r['core_union'];cap=r['cap_increment']
    core_table.append(f"| {labels[mode]} | {r['prefix']:.2f} / {r['suffix']:.2f} | {100*v['paired_delta']/v['baseline']:+.3f}% | {cap['paired_delta']:.2f} ± {cap['paired_ci95']:.2f} |")
profile=json.loads(Path('.scratch/inflation/profile/summary.json').read_text());profile_table=[]
for mode in ('baseline','local_budget','area','caps_balanced_bounded'):
    r=next(r for r in profile if r['mode']==mode)['runs'][0]
    profile_table.append('| '+labels[mode]+' | '+' | '.join(f"{r[k]:.2f}" for k in ('cover_ms','setup_ms','assembly_ms','solve_ms','line_ms','certificate_ms','local_ms'))+' |')
maximum_c2=max(r.get('c2_error',0) for r in dev+selected+hold);maximum_rss=max(r['max_rss_kib'] for r in dev+selected+hold)/1024
doc=f'''# C3 走廊空间膨胀：第一轮实验

## 结论

端部扩张是本轮最明确的体积来源。保留原路径的物理节点位置后，延伸对中段的扰动明显减小，也避免了开发集中一次额外 Jacobian 修复。按控制点数分配 Newton 预算，可以进一步降低生成耗时；其代价是部分路径中段体积略有下降。

局部五变量膨胀、加大分离面尺度、额外体积修正和截面投影面积目标均已实现并完成消融。它们尚未形成同时改善体积、耗时和平滑性的通用替代方案。正式头文件库和 RViz 默认入口未切换。

![同输入走廊](validation/inflation_round1/same_input_corridors.png)

最新点击路径为 45.76 m。以下时间均为复用 BVH 的完整生成时间中位数，包含端部处理与重试；FIRI 使用原来的四轮实现和相同实体障碍模型。

| 方法 | 生成 / ms | 并集体积 / m³ | 原路径区间边界弯曲能量 |
|---|---:|---:|---:|
{chr(10).join(latest_table)}

这条路径中，预算平衡版相对当前 C3 增加约 9.35% 总体积，耗时增加约 0.44 ms；相对 FIRI 的体积约高 4.57%，耗时约低 4.17%。这是单例结果，不能代表所有场景。

| 端部方案 | 起点外 / 终点外延伸 / m | 原路径区间体积变化 | 端部净新增体积 / m³（95% 区间半宽） |
|---|---:|---:|---:|
{chr(10).join(core_table)}

中段与端部采用各自的配对采样域，因此估计值相加会有小幅采样差异。节点对齐的完整迭代版几乎保留了本例中段体积；预算平衡版中段减少约 1.30%，用更低计算成本换取稍小的最终走廊。

## 公平性与输入

基线来自 `ros2` 的 `4a210a1`，包含当时工作区已有的交互演示改动。C3 生成头文件未改动；实验复制到私有目录后注入策略。最新路径的基线系数与交互导出逐字节一致。

共同设置：0.25 m 体素外接球、机器人半径 0.20 m、安全距离 0.05 m、认证余量 0.002 m、扩张范围 3 m、初始间距 0.4 m、长边切分 7 m、标架平滑 1.5。所有输入记录 SHA256。

端部扩张仍受**原种子路径的首末扩张盒**限制。点击的起终点作为必须包含的内部点，扩张结果检查包含关系；失败重试的时间保留。原路径区间与端部体积单独计算，端部重叠部分不重复计数。

开发集 8 条路径，每配置预热 1 次、重复 7 次；另 60 条冻结路径用于扩展回归，每配置预热 1 次、重复 3 次。扩展集包含 Perlin、迷宫、S 弯、变截面管道、螺旋、竖直路径和两个失败对照。同地图的多条路径是回归覆盖，不视为独立地图统计样本。

## 八例消融

表中耗时、并集体积和弯曲能量的变化均为逐场景配对百分比的中位数；体积范围保留最差和最好案例。耗时为正表示变慢，弯曲能量为负表示更平滑。

| 配置 | 耗时变化 | 并集体积变化 | 并集体积变化范围 | 边界弯曲能量变化 |
|---|---:|---:|---:|---:|
{chr(10).join(table)}

![配对指标](validation/inflation_round1/paired_metrics.png)

### 端部延伸

直接追加 C² 三次曲面可以保持旧曲面完全不变，但旧端点的一二阶导数经常限制可延伸长度。重新生成延长后的路径能获得更大的端部空间，却会改变原节点采样位置。`caps_aligned` 保留原物理节点，仅在两端增加节点，解决了这个不必要的扰动。

`caps_balanced` 用控制点数与 Newton 步数的乘积近似求解工作量。设原、新控制点数为 N0、N1，首阶段次数为 `clamp(round(14*N0/N1 - 6), 7, 8)`；后两阶段仍各三次。它不按案例编号挑选参数。体积增加主要来自端部，中段变化见完整 CSV 和各例的 `core_union` 字段。

### 局部椭圆膨胀

每个控制节点的五变量问题保留所有关联区间的 SOC 支撑约束与进度锥。有限差分、完整目标梯度/Hessian 对照均通过，C² 由控制空间直接保证。额外局部求解成本尚未被减少的全局迭代抵消，体积收益也不稳定。此前独立截面的 7.75% 面积潜力没有直接转化为连续走廊收益，说明连续耦合与可实现性必须纳入判断。

### 分离面尺度与目标函数

加大分离面代理椭球的纵向尺度能够减少部分计算和边界起伏，但经常损失体积。本轮没有把它作为默认改进。

`area` 优化的是实际截面位置上、固定参考标架投影并对称化后的 SPD 面积代理，不是精确三维截面面积。梯度、Hessian、步长域和线搜索一起更新，仍保持凸子问题和原来的带宽。它带来了小幅体积变化，但额外成本与边界起伏使它暂不适合替换基线。

额外局部体积修正的并集体积变化约为 0.003%–0.025%，远小于端部扩张；部分差异接近采样误差，其成本不值得默认引入。

## 另 60 条路径的回归

以下结果保留失败案例，并对基线和候选共同成功的路径计算配对指标。最后一列列出配对差的 95% 区间完全小于零的案例；这是逐例采样误差区间，未作多重比较校正。

| 配置 | 生成成功 | 耗时变化中位数 | 并集体积变化中位数 | 体积变化范围 | 弯曲能量变化中位数 | 下降区间低于零的案例 |
|---|---:|---:|---:|---:|---:|---|
{chr(10).join(hold_table)}

基线同样成功 58/60；失败对照为折返尖点和 0.03 m 窄口。案例 8、17 使用四倍采样复核：案例 8 的体积变化约 −0.008% ± 0.023%，尚不能区分与零的差别；案例 17 为 −0.195% ± 0.031%，扩张增加的端部空间未完全补回中段损失。

早期未限制加密的端部方案在案例 25、32、33 中初始化失败，并执行了六轮全局加密后才回退。案例 33 的单次诊断约为 1788 ms，其中扩张尝试约 1728 ms。限制端部候选加密后，三例回退总耗时分别约 46、60、81 ms；原走廊几何保持不变。案例 33 仍有约 21 ms 的失败尝试成本，后续局部端部求解需要继续降低这项开销。表中使用限制加密后的版本。

## 验证与资源

所有成功输出均通过连续支撑与全截面 Jacobian 认证。局部目标梯度误差约 3.33e-11，Hessian 误差约 1.27e-10；另有与完整目标的导数一致性、截面面积代理导数、精确线搜索差值和曲面裁剪测试。全部记录的最大 C² 接缝误差为 {maximum_c2:.3g}，按原路径长度对导数归一化。

并集体积使用独立三维求交、Sobol 采样和 8 次随机数字平移，每次 65,536 点；每对配置共 524,288 点。扩展集案例 8、17 提高到每次 262,144 点，共 2,097,152 点。所有测量的未决反求根计数为零。完整数据保留配对差和 95% 区间，不能只凭微小点估计宣布提升。边界弯曲能量使用原路径弧长参数，在原路径区间计算。

补充了贴近世界边界时延伸长度趋零的测试：路径插点和 knot 向量使用同一阈值。修正后重放 68 条输入、3 个配置，204 个状态一致；198 个成功输出的完整曲面、原路径区间曲面及支撑平面均逐字节一致。

所有计算串行，固定 CPU 2，数值线程为 1，进程地址空间上限 4 GiB。生成阶段观测到的峰值 RSS 为 {maximum_rss:.1f} MiB。BVH 构建时间另列，冷启动应加上该项。没有运行轨迹优化。

### 阶段计时

以下为最新路径打开计时后的单次诊断，单位 ms，用于定位成本，不替代前面的七次统计。部分字段属于嵌套阶段，不应直接相加；正常性能测量关闭高频阶段时钟。

| 配置 | 障碍覆盖 | 求解构造 | Hessian 组装 | 线性求解 | 线搜索 | 求解器认证 | 额外局部膨胀 |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(profile_table)}

## 下一步

优先研究端部局部重优化：允许首末几个控制块重新分配形状和导数，同时固定远处中段，复用原有覆盖与带状结构。它针对本轮暴露的矛盾：完全固定端点 jet 会限制扩张，全路径重生成又为新增端部支付了过多计算。

中段空间利用率的下一步应围绕活跃约束定位展开，区分真正的 Jacobian 限制、控制凸包限制和椭圆截面自身的角落损失。当前结果不支持直接增加全局迭代数或统一放大分离面尺度。

实验入口：[说明与命令](../SweepCorridor/experiments/inflation/README.md)。数据：[逐例 CSV](validation/inflation_round1/comparison.csv)，完整计时、输入摘要与压缩系数保存在同目录。
'''
(Path('docs')/'C3空间膨胀第一轮实验.md').write_text(doc)
print('Wrote report, comparison.csv and figures to',out)
