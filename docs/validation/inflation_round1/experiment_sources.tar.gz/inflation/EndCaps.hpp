// SPDX-License-Identifier: MIT
#pragma once
#include <Eigen/LU>
namespace sc_inflation {
struct CapResult {double prefix=0,suffix=0,begin=0,end=1;int attempts=0;};
struct Cap {c3::Geometry geometry;std::vector<sc::SupportPlane> planes;double width=0,distance=0;};
inline c3::Geometry endpointCurve(const sc::Section& s,double distance,bool reverse) {
  static const c3::CubicBasis basis({0.,1./3,2./3,1.});
  static const Eigen::Matrix<double,6,6> inverse=[] {
    Eigen::Matrix<double,6,6> a=Eigen::Matrix<double,6,6>::Zero();
    a.block<3,4>(0,0)=basis.jet(0,0);a.block<3,4>(3,2)=basis.jet(2,1);return a.inverse().eval();}();
  const double width=distance/s.first.norm(),sign=reverse?-1.:1.;
  Eigen::Matrix<double,6,9> rhs;rhs.row(0)=c3::pack(s.center,s.shape);
  rhs.row(1)=sign*width*c3::pack(s.first,s.shape_first);rhs.row(2)=width*width*c3::pack(s.second,s.shape_second);
  rhs.row(3)=c3::pack(s.center+sign*distance*s.first.normalized(),.8*s.shape);
  rhs.row(4)=c3::pack(sign*distance*s.first.normalized(),sc::Mat32::Zero());rhs.row(5).setZero();
  const Eigen::Matrix<double,6,9> x=inverse*rhs;std::vector<c3::V9> controls(6);for(int i=0;i<6;++i)controls[i]=x.row(i).transpose();
  return c3::Geometry::fromCubic(basis,controls);
}
inline CapResult append(c3::CubicResult& result,const sc::ObstacleIndex& map,const sc::Bounds& bounds,const sc::Options& options) {
  CapResult info;const auto original=result.corridor;const auto old_planes=result.cover;
  auto make=[&](bool reverse){Cap cap;const auto s=original.section(reverse?0:1);const sc::Vec3 direction=(reverse?-1.:1.)*s.first.normalized();
    const double proposed=extension(s.center,direction,map,bounds,options);
    for(double distance=proposed;distance>=.05&&info.attempts<14;distance*=.5){++info.attempts;auto g=endpointCurve(s,distance,reverse);
      if(reverse)std::reverse(g.controls.begin(),g.controls.end());
      c3::Certificate jac;bool valid=true;for(int j=0;j<int(g.pieces());++j)valid&=c3::jacobianCertificate<3>(g.curve(j),jac);if(!valid)continue;
      const std::vector<sc::Vec3> seed{s.center,s.center+distance*direction};
      const auto& box=c3::experiment::endpoint_boxes[reverse?0:1];
      const double pad=options.robot_radius+options.safety_margin+options.certificate_margin;
      const sc::Bounds cap_world{box.lower-sc::Vec3::Constant(pad),box.upper+sc::Vec3::Constant(pad)};
      try{c3::QueryCache cache;c3::CoverMetrics metrics;c3::Deadline deadline(options.budget_ms,c3::Clock::now());
        const c3::CoverLayout layout(g.breaks,seed,cap_world,options);
        auto planes=c3::mapCover(g,map,cap_world,options,cache,metrics,deadline,layout,false);
        if(!c3::certify(g,planes).safe())continue;
        cap={std::move(g),std::move(planes),distance/s.first.norm(),distance};break;
      }catch(const c3::Failure&){}
    }return cap;};
  const Cap first=make(true),last=make(false);const double width=1+first.width+last.width;
  c3::Geometry out;out.breaks.push_back(0);std::vector<sc::SupportPlane> planes;
  if(first.width>0){for(int i=0;i<int(first.geometry.pieces());++i){const auto curve=first.geometry.curve(i);
      out.controls.insert(out.controls.end(),curve.begin(),curve.end());out.breaks.push_back(first.width*first.geometry.breaks[i+1]/width);}
    planes.insert(planes.end(),first.planes.begin(),first.planes.end());}
  const int offset=int(out.pieces());for(int i=0;i<int(original.pieces());++i){const auto curve=original.curve(i);out.controls.insert(out.controls.end(),curve.begin(),curve.end());out.breaks.push_back((first.width+original.breaks[i+1])/width);}
  for(auto p:old_planes){p.span+=offset;planes.push_back(p);}
  const int last_offset=int(out.pieces());if(last.width>0){for(int i=0;i<int(last.geometry.pieces());++i){const auto curve=last.geometry.curve(i);
      out.controls.insert(out.controls.end(),curve.begin(),curve.end());out.breaks.push_back((first.width+1+last.width*last.geometry.breaks[i+1])/width);}
    for(auto p:last.planes){p.span+=last_offset;planes.push_back(p);}}
  result.corridor=std::move(out);result.cover=std::move(planes);
  info.prefix=first.distance;info.suffix=last.distance;info.begin=first.width/width;info.end=(first.width+1)/width;return info;
}
}
