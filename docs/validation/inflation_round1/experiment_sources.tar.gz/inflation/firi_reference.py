#!/usr/bin/env python3
"""Auxiliary FIRI reference, using the same production wrapper as RViz."""
import argparse,json,os,resource,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('report');p.add_argument('--binary',default='build/gcopter/corridor_firi_benchmark');p.add_argument('--samples',type=int,default=65536);a=p.parse_args()
os.chdir(Path(__file__).resolve().parents[3]);resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
root=Path(a.report);manifest=json.loads((root/'manifest.json').read_text());summary=[]
for case in manifest['cases']:
    target=root/f"case_{case['case']:02d}"/'firi';target.mkdir(parents=True,exist_ok=True)
    command=[str(Path(a.binary).resolve()),case['seed'],case['map'],str(target),'solid',*map(str,case['bounds_lower']+case['bounds_upper']),'.25',str(manifest['repeats']),str(a.samples),'matched-box','3']
    with (target/'process.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    record=dict(case=case['case'],returncode=result.returncode,command=command)
    if (target/'metrics.json').exists():record.update(json.loads((target/'metrics.json').read_text()))
    summary.append(record);(root/'firi_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(case['case'],'FIRI',result.returncode,record.get('firi_median_ms'),record.get('firi_union_m3'),flush=True)
