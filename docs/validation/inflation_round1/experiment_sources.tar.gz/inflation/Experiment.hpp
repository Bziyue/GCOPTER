// SPDX-License-Identifier: MIT
// Experimental policies. prepare.py injects this into a PRIVATE header snapshot.
// The installed library and ROS demo never include this file.
#pragma once
#include "CubicOptimizer.hpp"
#include "CubicVolume.hpp"
#include "ExperimentConfig.hpp"
#include <Eigen/Cholesky>
#include <numeric>

namespace SweepCorridor::internal::cubic::experiment {
using V5=Eigen::Matrix<double,5,1>;
using M5=Eigen::Matrix<double,5,5>;
using J35=Eigen::Matrix<double,3,5>;

inline J35 mapping(const Eigen::Vector2d& n,double center_sign=1) {
  J35 j=J35::Zero();j(0,0)=-center_sign*n[0];j(0,1)=-center_sign*n[1];
  j(1,2)=n[0];j(1,3)=n[1];j(2,3)=n[0];j(2,4)=n[1];return j;
}
struct Row { J35 j; Vec3 base; M5 second; };
struct Neighborhood {
  std::vector<std::vector<std::pair<int,int>>> groups,cuts;
  explicit Neighborhood(const CubicProblem& p):groups(p.model.basis.count),cuts(groups.size()) {
    for(int k=0;k<int(p.geometry->groups.size());++k){const auto& g=p.geometry->groups[k];
      for(int j=0;j<g.count;++j)groups[g.first/5+j].push_back({k,j});}
    for(int k=0;k<int(p.cuts.size());++k){const auto& c=p.cuts[k];
      for(int j=0;j<c.count;++j)cuts[c.first/5+j].push_back({k,j});}
  }
  std::vector<Row> rows(const CubicProblem& p,const Eigen::VectorXd& x,int node)const {
    std::vector<Row> out;out.reserve(256);const V5 local=x.segment<5>(5*node);
    auto add=[&](const J35& j,const Vec3& value){
      const J35 signed_j=(Vec3(1,-1,-1).asDiagonal()*j).eval();
      out.push_back({j,value-j*local,2*j.transpose()*signed_j});};
    for(auto [id,k]:groups[node]){const auto& g=p.geometry->groups[id];const V9 y=g.geometry(x);
      for(size_t i=0;i<g.retained;++i){const auto& s=g.supports[i];add(mapping(g.maps[k].transpose()*s.normal),s.project(y));}}
    for(auto [id,k]:cuts[node]){const auto& c=p.cuts[id];const Vec3 y=c.apply(x);
      add(mapping(c.normals[k],c.center_sign),Vec3(c.bound-y[0],y[1],y[2]));}
    return out;
  }
};
inline double objective(const V5& x,const std::vector<Row>& rows,const M5& q,const V5& linear,
                        const GeometryOptions& options,double weight,double mu,V5* gradient=nullptr,M5* hessian=nullptr) {
  double cost=.5*x.dot(q*x)+linear.dot(x);V5 g=q*x+linear;M5 h=q;
  auto detTerm=[&](double a,double b,double c,double w,double sign){
    const double det=a*c-b*b;if(!(a>0&&det>0))return false;
    cost-=w*std::log(det);
    if(gradient){V5 d=V5::Zero();d.tail<3>()=sign*Vec3(c,-2*b,a);g-=w*d/det;
      M5 dd=M5::Zero();dd(2,4)=dd(4,2)=1;dd(3,3)=-2;h+=w*(d*d.transpose()/(det*det)-dd/det);}
    return true;};
  if(!detTerm(x[2],x[3],x[4],weight,1)||
     !detTerm(x[2]-options.min_radius,x[3],x[4]-options.min_radius,mu,1)||
     !detTerm(options.max_radius-x[2],-x[3],options.max_radius-x[4],mu,-1))return INFINITY;
  const double gap=options.max_offset*options.max_offset-x.head<2>().squaredNorm();
  if(!(gap>0))return INFINITY;cost-=mu*std::log(gap);
  if(gradient){g.head<2>()+=2*mu*x.head<2>()/gap;
    h.topLeftCorner<2,2>()+=2*mu/gap*Eigen::Matrix2d::Identity()+4*mu/(gap*gap)*x.head<2>()*x.head<2>().transpose();}
  for(const auto& row:rows){const Vec3 v=row.base+row.j*x;
    const double slack=v[0]*v[0]-v.tail<2>().squaredNorm();
    if(!(v[0]>0&&slack>0))return INFINITY;cost-=mu*std::log(slack);
    if(gradient){const V5 d=2*row.j.transpose()*Vec3(v[0],-v[1],-v[2]);
      g-=mu*d/slack;h+=mu*(d*d.transpose()/(slack*slack)-row.second/slack);}}
  if(gradient){*gradient=g;*hessian=h;}return cost;
}
inline void inflate(const CubicProblem& p,Eigen::VectorXd& x) {
  if(!config.local_steps)return;
  const auto start=Clock::now();const Neighborhood neighborhood(p);const int count=p.model.basis.count;
  for(int node=0;node<count;++node){
    const int first=5*node;const V5 initial=x.segment<5>(first);V5 value=initial;
    const auto rows=neighborhood.rows(p,x,node);M5 q;V5 linear=p.linear.segment<5>(first);
    for(int j=0;j<5;++j){for(int k=0;k<5;++k)q(j,k)=p.quadratic.get(first+j,first+k);
      for(int k=std::max(0,first+j-BandedSPD::width);k<=std::min(int(x.size())-1,first+j+BandedSPD::width);++k)
        if(k<first||k>=first+5)linear[j]+=p.quadratic.get(first+j,k)*x[k];}
    const double weight=p.model.basis.weight(node),mu=.003/count;
    for(int it=0;it<config.local_steps;++it){V5 g;M5 h;
      const double f=objective(value,rows,q,linear,p.options,weight,mu,&g,&h);
      if(!std::isfinite(f))break;
      if(node==0||node+1==count){g.head<2>().setZero();for(int j=0;j<2;++j){h.row(j).setZero();h.col(j).setZero();h(j,j)=1;}}
      const V5 direction=h.ldlt().solve(-g);const double slope=g.dot(direction);
      if(!std::isfinite(slope)||slope>=-1e-9)break;
      double alpha=1;bool accepted=false;
      for(int backtrack=0;backtrack<20;++backtrack,alpha*=.5){const V5 next=value+alpha*direction;
        if(objective(next,rows,q,linear,p.options,weight,mu)<=f+.01*alpha*slope){value=next;accepted=true;break;}}
      if(!accepted)break;++stats.local_steps;
    }
    x.segment<5>(first)=value;++stats.local_blocks;
  }
  stats.local_ms+=elapsedMs(start);
}
template<int D> inline double longitudinal(const Curve<D,Vec3>& c,const Curve<D,Mat32>& m,double minimum) {
  const double base=std::max(.5*(c[D]-c[0]).norm(),minimum);
  if(config.metric_length==0)return base;
  const Vec3 a=m[0].col(0).cross(m[0].col(1)).normalized(),b=m[D].col(0).cross(m[D].col(1)).normalized();
  const double angle=(a-b).norm(),curvature=angle/std::max(2*base,1e-6);
  return std::max(base,std::min(config.metric_length,.3/std::max(curvature,1e-6)));
}
inline double bending(const Geometry& g) {
  double energy=0;
  for(int i=0;i<int(g.pieces());++i){const double h=g.breaks[i+1]-g.breaks[i];const auto p=g.curve(i);
    for(double t:{.5-.5/std::sqrt(3.),.5+.5/std::sqrt(3.)}){
      const V9 dd=(6/(h*h))*((1-t)*(p[2]-2*p[1]+p[0])+t*(p[3]-2*p[2]+p[1]));
      energy+=.5*h*(dd.head<3>().squaredNorm()+.5*dd.tail<6>().squaredNorm());}}
  return energy;
}
inline void refine(const CubicProblem& p,Eigen::VectorXd& x,const std::function<bool(const Eigen::VectorXd&)>& certificate) {
  if(!config.volume_passes)return;const auto start=Clock::now();
  for(int pass=0;pass<config.volume_passes;++pass){
    Eigen::VectorXd gradient,unused;BandedSPD h;
    const double before=sweptVolume(p.model,x,&gradient),smooth=bending(p.model.geometry(x));
    p.objective(x,.00001/p.model.basis.count,&unused,&h,false);
    std::vector<std::pair<double,int>> ranked;std::vector<V5> directions(p.model.basis.count);
    for(int node=1;node+1<p.model.basis.count;++node){M5 block;for(int j=0;j<5;++j)for(int k=0;k<5;++k)block(j,k)=h.get(5*node+j,5*node+k);
      V5 d=block.ldlt().solve(gradient.segment<5>(5*node));
      const double movement=d.head<2>().norm()+std::sqrt(d[2]*d[2]+2*d[3]*d[3]+d[4]*d[4]);
      d*=std::min(1.,.1/std::max(movement,1e-30));directions[node]=d;
      ranked.push_back({gradient.segment<5>(5*node).dot(d),node});}
    std::sort(ranked.rbegin(),ranked.rend());std::vector<bool> chosen(p.model.basis.count,false);
    Eigen::VectorXd direction=Eigen::VectorXd::Zero(x.size());
    for(auto [gain,node]:ranked){if(gain<=0)continue;bool adjacent=false;
      for(int j=std::max(0,node-3);j<=std::min(p.model.basis.count-1,node+3);++j)adjacent|=chosen[j];
      if(!adjacent){chosen[node]=true;direction.segment<5>(5*node)=directions[node];}}
    double alpha=p.feasibleStep(x,direction);
    for(int trial=0;trial<8;++trial,alpha*=.5){const Eigen::VectorXd next=x+alpha*direction;
      if(sweptVolume(p.model,next)>before+1e-10&&bending(p.model.geometry(next))<=1.02*smooth&&certificate(next)){
        x=next;++stats.volume_accepts;break;}}
  }
  stats.volume_ms+=elapsedMs(start);
}
} // namespace SweepCorridor::internal::cubic::experiment
