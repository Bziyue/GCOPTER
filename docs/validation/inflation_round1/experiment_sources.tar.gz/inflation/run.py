#!/usr/bin/env python3
"""Serial paired-input experiments. A failed generation remains in the report."""
import argparse,hashlib,json,os,resource,shutil,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--build',default='.scratch/inflation');p.add_argument('--output',required=True)
p.add_argument('--inputs',default='.scratch/native_splines/e1/inputs/manifest.json');p.add_argument('--cases',default='0,1,2,3,4,5,6,67')
p.add_argument('--modes',default='baseline,caps,local,local_budget,metric_short,metric,volume,hybrid,hybrid_caps')
p.add_argument('--repeats',type=int,default=7);p.add_argument('--samples',type=int,default=65536);a=p.parse_args()
repo=Path(__file__).resolve().parents[3];os.chdir(repo)
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
build=Path(a.build).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
cases=json.loads(Path(a.inputs).read_text())['cases']
source=Path('.scratch/volume_diagnosis/source.json')
if source.exists() and not any(c['case']==67 for c in cases):
    d=json.loads(source.read_text());m=d['metrics'];req=Path(d['request'])
    cases.append(dict(case=67,family='rviz_latest',group='development',source=str(req),seed=str(req/'seed.xyz'),map=str(req.parent/f"map_{m['map_version']}.xyz"),bounds_lower=m['bounds_lower'],bounds_upper=m['bounds_upper'],resolution=.25))
selected=None if a.cases=='all' else set(map(int,a.cases.split(',')));cases=[c for c in cases if selected is None or c['case'] in selected]
cache={};frozen=[]
for row in cases:
    row=dict(row)
    for key in ('seed','map'):
        src=Path(row[key]);digest=cache.setdefault(str(src),hashlib.sha256(src.read_bytes()).hexdigest())
        if key+'_sha256' in row:assert row[key+'_sha256']==digest
        dest=build/'inputs'/f'{key}_{digest}.xyz';dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copyfile(src,dest)
        row[key]=str(dest);row[key+'_sha256']=digest
    frozen.append(row)
manifest=dict(cases=frozen,repeats=a.repeats,samples_per_shift=a.samples,shifts=8,memory_limit=4*1024**3,cpu=2,
              commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),build=json.loads((build/'build.json').read_text()),
              binary_sha256=hashlib.sha256((build/'benchmark').read_bytes()).hexdigest())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
modes=a.modes.split(',');summary=[]
for case in frozen:
    mode_order=modes if case['case']%2==0 else modes[::-1]
    records={}
    for mode in mode_order:
        target=out/f"case_{case['case']:02d}"/mode;target.mkdir(parents=True,exist_ok=True)
        cmd=[str(build/'benchmark'),case['seed'],case['map'],str(target),*map(str,case['bounds_lower']+case['bounds_upper']),str(a.repeats),mode]
        with (target/'process.log').open('w') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
        if result.returncode:raise RuntimeError((case['case'],mode,result.returncode,(target/'process.log').read_text()))
        rows=[json.loads(l) for l in (target/'rows.jsonl').read_text().splitlines()]
        runs=[r for r in rows if r.get('repeat',-1)>=0];times=sorted(r['wall_ms'] for r in runs)
        record=dict(case=case['case'],family=case['family'],mode=mode,median_ms=statistics.median(times),p95_ms=times[min(len(times)-1,int(.95*len(times)))],
                    runs=runs,max_rss_kib=rows[-1]['max_rss_kib'],success=all(r['status']=='SUCCESS' for r in runs),output=str(target))
        if record['success']:
            geometry=target/'corridor.csv';record['geometry_sha256']=hashlib.sha256(geometry.read_bytes()).hexdigest()
            for key in ('swept_volume','core_swept_volume','boundary_bending','max_curvature','c2_error','min_axis','prefix','suffix','retries','newton_steps','regularity_repairs','local_ms','extra_volume_accepts'):
                record[key]=runs[0][key]
        records[mode]=record;summary.append(record)
        (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(case['case'],mode,'PASS' if record['success'] else [r['status'] for r in runs],round(record['median_ms'],3),
              round(record.get('core_swept_volume',0),3),flush=True)
    if a.samples and 'baseline' in records and records['baseline']['success']:
        base=Path(records['baseline']['output'])/'corridor.csv'
        for mode,record in records.items():
            if mode=='baseline' or not record['success']:continue
            target=Path(record['output'])
            for label,name in [('union','corridor.csv'),('core_union','core.csv')]:
                if label=='core_union' and (target/name).read_bytes()==(target/'corridor.csv').read_bytes():record[label]=record['union'];continue
                cmd=[str(build/'measure'),str(base),str(target/name),case['seed'],str(a.samples)]
                measured=json.loads(subprocess.check_output(cmd,text=True,timeout=180));assert measured['unresolved']==0
                record[label]=measured
                (target/(label+'.json')).write_text(json.dumps(measured,indent=2)+'\n')
            print('union',case['case'],mode,round(100*record['union']['paired_delta']/record['union']['baseline'],3),'%',flush=True)
        (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
