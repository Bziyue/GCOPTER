// SPDX-License-Identifier: MIT
#pragma once
#include "ExperimentConfig.hpp"
#include "CubicOptimizer.hpp"
#include <Eigen/Eigenvalues>
namespace SweepCorridor::internal::cubic::experiment {
// Project into a fixed polar-aligned reference frame and symmetrize. This is an
// affine SPD surrogate of the actual section area, keeping the Newton problem
// convex and its half-bandwidth unchanged. Exact area/volume remain outputs.
inline std::vector<AreaProbe> makeAreaProbes(const CubicModel& m) {
  std::vector<AreaProbe> probes;probes.reserve(m.basis.spans.size());
  for(int span=0;span<int(m.basis.spans.size());++span){
    const Eigen::Vector4d w=m.basis.spans[span].extraction.transpose()*Eigen::Vector4d(.125,.375,.375,.125);
    Mat32 f=Mat32::Zero();for(int j=0;j<4;++j)f+=w[j]*m.frames[span+j];
    const Eigen::SelfAdjointEigenSolver<Eigen::Matrix2d> eig(f.transpose()*f);
    const Mat32 frame=f*eig.eigenvectors()*eig.eigenvalues().cwiseSqrt().cwiseInverse().asDiagonal()*eig.eigenvectors().transpose();
    AreaProbe p;p.first=span;p.weight=m.basis.breaks[span+1]-m.basis.breaks[span];p.map.setZero();
    for(int j=0;j<4;++j){const Eigen::Matrix2d a=w[j]*frame.transpose()*m.frames[span+j];
      p.map.block<3,3>(0,3*j)<<a(0,0),a(0,1),0,.5*a(1,0),.5*(a(1,1)+a(0,0)),.5*a(0,1),0,a(1,0),a(1,1);}
    probes.push_back(p);
  }return probes;
}
inline double areaObjective(const CubicProblem& problem,const Eigen::VectorXd& x,Eigen::VectorXd* gradient,BandedSPD* hessian,bool cost) {
  double result=0;
  for(const auto& p:problem.energy->area){Eigen::Matrix<double,12,1> local;
    for(int j=0;j<4;++j)local.segment<3>(3*j)=x.segment<3>(5*(p.first+j)+2);
    const Vec3 s=p.map*local;const double det=s[0]*s[2]-s[1]*s[1];if(!(s[0]>0&&det>0))return INFINITY;
    if(cost)result-=p.weight*std::log(det);
    if(gradient){const double a=s[2]/det,b=-s[1]/det,c=s[0]/det;
      const Eigen::Matrix<double,12,1> g=-p.weight*p.map.transpose()*Vec3(a,2*b,c);
      for(int j=0;j<4;++j)gradient->segment<3>(5*(p.first+j)+2)+=g.segment<3>(3*j);
      if(hessian){Eigen::Matrix3d hs;hs<<a*a,2*a*b,b*b,2*a*b,2*(a*c+b*b),2*b*c,b*b,2*b*c,c*c;
        const Eigen::Matrix<double,12,12> h=p.weight*p.map.transpose()*hs*p.map;
        for(int j=0;j<12;++j)for(int k=0;k<=j;++k)hessian->add(5*(p.first+j/3)+2+j%3,5*(p.first+k/3)+2+k%3,h(j,k));}}
  }return result;
}
template<class F> inline void areaShapes(const CubicEnergy& energy,const Eigen::VectorXd& x,const Eigen::VectorXd& direction,F&& apply) {
  for(const auto& p:energy.area){Eigen::Matrix<double,12,1> local,delta;
    for(int j=0;j<4;++j){local.segment<3>(3*j)=x.segment<3>(5*(p.first+j)+2);delta.segment<3>(3*j)=direction.segment<3>(5*(p.first+j)+2);}
    const Vec3 s=p.map*local,d=p.map*delta;Eigen::Matrix2d a,b;a<<s[0],s[1],s[1],s[2];b<<d[0],d[1],d[1],d[2];apply(a,b,p.weight);}
}
}
