# C3 空间膨胀实验

本目录研究端部延伸、局部椭圆膨胀、分离面尺度、截面积目标和体积修正。实验通过 `prepare.py` 在 `.scratch` 中复制头文件并注入策略；正式 `SweepCorridor/include`、安装接口和 RViz 默认入口保持独立。

所有对照使用相同原始地图与种子路径、0.25 m 体素外接球、0.20 m 机器人半径、0.05 m 安全距离、0.002 m 认证余量和 3 m 扩张范围。新增端部也限制在**原种子路径首末扩张盒**中，不额外扩大允许的搜索区域。输入以 SHA256 冻结。

## 运行

从仓库根目录执行：

```bash
python3 SweepCorridor/experiments/inflation/prepare.py
.scratch/inflation/tests
python3 SweepCorridor/experiments/inflation/run.py \
  --output .scratch/inflation/replay \
  --cases 0,1,2,3,4,5,6,67 --repeats 7 --samples 0 \
  --modes baseline,caps_aligned_bounded,caps_balanced_bounded
python3 SweepCorridor/experiments/inflation/measure_all.py .scratch/inflation/replay
python3 SweepCorridor/experiments/inflation/firi_reference.py .scratch/inflation/replay
```

默认读取已有冻结输入清单 `.scratch/native_splines/e1/inputs/manifest.json`；用 `--inputs` 可以替换。案例 67 从前次局部诊断保存的交互请求中冻结。迁移机器时，应一并复制清单中引用的输入文件。生成器和 FIRI 均串行运行；脚本将地址空间限制为 4 GiB、CPU 固定到 2、数值线程设为 1。测量阶段不计入生成耗时。

## 策略

| 模式 | 实现 |
|---|---|
| `baseline` | 当前正式 C3；导出系数与原基线核对 |
| `caps` | 沿原始首末切线检查延伸净空，取 80% 后重新生成；验证原点击点仍在走廊内 |
| `caps_aligned` | 延伸时保持原路径的物理节点位置，只在端部添加节点 |
| `caps_aligned_budget` | 节点对齐，首阶段固定 7 次 Newton 预算 |
| `caps_balanced` | 节点对齐，按新增控制点数量将首阶段预算选为 7 或 8 次；两个后续阶段仍各 3 次 |
| `caps_aligned_bounded` / `caps_balanced_bounded` | 对应端部方案只尝试原密度初始化；失败直接回到原路径，避免为端部扩张全局加密六轮 |
| `append` | 保持原曲面不变，追加三个三次区间；通过六个端部 jet 条件建立 C² 接缝，再独立连续认证 |
| `local_budget` | 五变量局部条件膨胀，精确保留关联的 C3 支撑约束和进度锥；随后减少全局首阶段迭代 |
| `metric_short` / `metric` | 分离面代理椭球采用 0.5 / 1.0 m 纵向尺度上限，曲率较高时缩短 |
| `volume` | 额外两轮局部体积方向修正；单轮边界弯曲能量增加不超过 2% |
| `area` | 用实际截面位置的**固定标架投影面积代理**替换控制矩阵 `logdet`，并同步修改梯度、Hessian、步长边界及线搜索 |
| `metric_caps` / `area_metric_caps` / `area_append` | 对应组合消融 |

局部膨胀不是无约束截面 MVIE 后再插值：每次只更新一个控制节点，其他节点给定，所有影响区间的 SOC 条件仍保留，因此 C² 结构保持不变。该方法目前用于检验局部求解是否能减少全局迭代成本。

`area` 的投影和对称化保持凸子问题与原带宽；它不是精确三维截面面积，也不是并集体积。报告中的实际体积由独立的三维并集测量获得。

`caps_balanced` 以“控制点数 × Newton 步数”作为工作量代理。若原控制点数为 N0、新控制点数为 N1，首阶段次数为 `clamp(round(14*N0/N1 - 6), 7, 8)`。该规则不根据地图编号或体积结果选参数。若扩张失败或未包含原点击点，则回到原路径生成，重试开销计入总时间。

扩展回归中，未限制加密的版本在三个案例中回退，其中一次耗时达到约 1.8 s。因此后续评估使用 `_bounded` 版本。它保留原路径生成器的正常加密能力，只关闭新增端部候选的全局加密；失败记录、阶段耗时和回退仍完整输出。其余旧模式用于复现消融。

## 测量与验证

- 生成计时包含路径延伸、原点包含检查和失败重试；BVH 构建时间单列。
- 开发集预热一次、重复七次，保留完整序列、中位数和 P95；扩展回归单列重复次数。
- 生成结果执行连续支撑证书和全截面 Jacobian 证书，并记录 C² 接缝误差。
- 并集体积使用同域配对 Sobol 采样，8 次随机数字平移，每次 65,536 点；输出配对差及 95% 区间。
- 总体积、原路径参数区间内体积、端部新增体积分别计算。新增端部与中段的重叠不重复计数。
- 边界平滑性采用原路径弧长参数下的 `∫(||c''||² + 0.5||M''||F²) ds`，在原路径区间计算，避免仅靠延长参数域稀释能量。
- `tests.cpp` 检查局部目标梯度/Hessian、局部约束与完整目标导数的一致性、截面面积代理的梯度/Hessian及线搜索、曲面裁剪和连续认证。

每个实验目录含 `manifest.json`、`summary.json`、完整计时、曲面系数和支撑平面。失败结果保留在统计中；本实验不运行轨迹优化。

本轮结果见 [实验报告](../../../docs/C3空间膨胀第一轮实验.md) 和 [压缩数据](../../../docs/validation/inflation_round1/README.md)。复现完整回归可使用 `--inputs docs/validation/inflation_round1/inputs.json --cases all`。该清单引用的地图快照需存在。

完成本轮 `final`、`selection`、`holdout_bounded` 及诊断批次后，重新生成图文和压缩结果：

```bash
python3 SweepCorridor/experiments/inflation/report.py
python3 SweepCorridor/experiments/inflation/archive.py
```
