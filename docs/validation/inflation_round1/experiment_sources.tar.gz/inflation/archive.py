#!/usr/bin/env python3
"""Archive numeric evidence and selected geometry without duplicating map clouds."""
import gzip,hashlib,json,os,resource,tarfile
from pathlib import Path

repo=Path(__file__).resolve().parents[3];os.chdir(repo)
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
root=Path('.scratch/inflation');out=Path('docs/validation/inflation_round1');out.mkdir(parents=True,exist_ok=True)
directories=('final','selection','holdout','retry_trace','holdout_bounded','edge','profile','final_equivalence')
results={}
for directory in directories:
    results[directory]={}
    for name in ('manifest.json','summary.json','firi_summary.json','verification.json'):
        source=root/directory/name
        if source.exists():results[directory][name]=json.loads(source.read_text())
results['test_log']=(root/'final_validation.log').read_text()
with (out/'results.json.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as file:
        file.write((json.dumps(results,separators=(',',':'))+'\n').encode())

cases={}
for directory in ('selection','holdout_bounded'):
    for row in results[directory]['manifest.json']['cases']:cases[row['case']]=row
(out/'inputs.json').write_text(json.dumps({'cases':[cases[k] for k in sorted(cases)]},indent=2)+'\n')

# Preserve the eight paired comparison geometries, certificates, and FIRI planes.
with (out/'geometry.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            def add(source,name):
                info=archive.gettarinfo(str(source),arcname=name)
                info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
                with source.open('rb') as file:archive.addfile(info,file)
            for row in results['selection']['summary.json']:
                for name in ('corridor.csv','core.csv','support_planes.csv'):
                    source=Path(row['output'])/name
                    if source.exists():add(source,f"case_{row['case']:02d}/{row['mode']}/{name}")
            for row in results['selection']['manifest.json']['cases']:
                name=f"case_{row['case']:02d}"
                add(Path(row['seed']),name+'/seed.xyz')
                add(root/'selection'/name/'firi/firi_planes.csv',name+'/firi/firi_planes.csv')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files=list(Path('SweepCorridor/experiments/inflation').glob('*'))
files+=list(Path('SweepCorridor/include').rglob('*.hpp'))
files+=list(Path('gcopter/tools').glob('corridor_*'))
files+=[Path('gcopter/include/gcopter/firi.hpp'),Path('build/gcopter/corridor_firi_benchmark'),root/'benchmark',root/'measure',root/'tests']
hashes={str(path):digest(path) for path in files if path.is_file()}
metadata={'source_and_binary_sha256':hashes,'geometry_scope':'selection: 8 cases x 3 configurations plus FIRI planes',
          'all_numeric_results':'results.json.gz','input_clouds':'Retained in the content-addressed local input directory; paths and SHA256 are in inputs.json.',
          'artifacts_sha256':{name:digest(out/name) for name in ('results.json.gz','geometry.tar.gz','inputs.json','comparison.csv','paired_metrics.png','same_input_corridors.png')}}
(out/'artifacts.json').write_text(json.dumps(metadata,indent=2)+'\n')
(out/'README.md').write_text('''# 第一轮空间膨胀实验数据

- `comparison.csv`：逐例耗时、并集体积、原路径区间体积和弯曲能量。
- `results.json.gz`：完整计时序列、失败状态、连续证书、输入摘要、构建记录和验证日志。
- `geometry.tar.gz`：8 条开发路径 × 3 个最终配置的完整曲面、原路径区间曲面、支撑平面，以及原始路径和 FIRI 平面。
- `inputs.json`：68 条冻结输入，含地图和路径的 SHA256；地图复用本地内容寻址快照，不重复提交大点云。
- `artifacts.json`：源码、可执行程序和数据产物的 SHA256。

结果分组：`final` 是同原始扩张盒下的完整消融；`selection` 是限制端部重试后的开发集；`holdout_bounded` 是对应的 60 条扩展回归。`holdout` 和 `retry_trace` 保留修正前的长尾与诊断，不能与最终配置混在一起计算耗时。`profile` 打开了阶段时钟，只用于定位成本；`final_equivalence` 验证趋零端部修正后的几何一致性。`edge` 是对应的世界边界案例。

读取原始数据：

```python
import gzip, json
with gzip.open("docs/validation/inflation_round1/results.json.gz", "rt") as file:
    results = json.load(file)
```

每次 QMC 结果中的 `samples` 是八个数字平移的总样本数。案例 8、17 使用四倍样本复核。原始输出路径指向本机实验目录；已归档的曲面可从 `geometry.tar.gz` 提取。
''')
print('Archived',len(cases),'inputs and',len(results)-1,'experiment batches into',out)
