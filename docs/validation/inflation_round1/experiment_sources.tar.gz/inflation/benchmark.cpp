#include "common.hpp"
#include "../../../gcopter/tools/corridor_volume.hpp"
#include <sys/resource.h>
namespace ex=c3::experiment;
inline std::vector<corridor_volume::Patch> patches(const c3::Geometry& g) {
  std::vector<corridor_volume::Patch> out(g.pieces());
  for(size_t i=0;i<out.size();++i){for(int j=0;j<4;++j){out[i].c[j]=g.controls[4*i+j].head<3>();out[i].m[j]=c3::shape(g.controls[4*i+j]);}out[i].prepare();}return out;
}
double extension(const sc::Vec3& point,const sc::Vec3& direction,const sc::ObstacleIndex& map,const sc::Bounds& bounds,const sc::Options& o) {
  const double pad=o.robot_radius+o.safety_margin+o.certificate_margin;double distance=o.local_range;
  for(int j=0;j<3;++j)if(std::abs(direction[j])>1e-12)distance=std::min(distance,((direction[j]>0?bounds.upper[j]-pad:bounds.lower[j]+pad)-point[j])/direction[j]);
  const sc::Vec3 end=point+distance*direction;std::vector<int> ids;
  map.query(point.cwiseMin(end)-sc::Vec3::Constant(pad),point.cwiseMax(end)+sc::Vec3::Constant(pad),ids);
  for(int id:ids){const auto& s=map.obstacles()[id];const sc::Vec3 d=s.center-point;const double t=d.dot(direction),perp=d.squaredNorm()-t*t,r=s.radius+pad;
    if(perp<r*r){const double enter=t-std::sqrt(std::max(0.,r*r-perp));if(enter>=0)distance=std::min(distance,enter);}}
  const double result=std::max(0.,.8*distance);
  // The seed and knot vector must agree when the available extension vanishes.
  return result>1e-6?result:0.;
}
#include "EndCaps.hpp"
int main(int argc,char** argv){try{
  if(argc!=12)throw std::runtime_error("seed map output xmin ymin zmin xmax ymax zmax repeats mode");
  const auto seed=readPoints(argv[1]),cloud=readPoints(argv[2]);if(seed.size()<2)throw std::runtime_error("short seed");
  std::vector<sc::Sphere> spheres;for(auto p:cloud)spheres.push_back({p,std::sqrt(3)*.25/2});
  const auto index_start=c3::Clock::now();const sc::ObstacleIndex map(std::move(spheres));const double index_ms=c3::elapsedMs(index_start);
  const sc::Bounds bounds{{std::stod(argv[4]),std::stod(argv[5]),std::stod(argv[6])},{std::stod(argv[7]),std::stod(argv[8]),std::stod(argv[9])}};
  auto options=optionsFor(seed,bounds);options.profile=std::getenv("INFLATION_PROFILE");c3::OptimizerSettings solver;solver.profile=options.profile;
  const std::string mode=argv[11];const bool bounded=mode=="caps_aligned_bounded"||mode=="caps_balanced_bounded";
  const bool balanced=mode=="caps_balanced"||mode=="caps_balanced_bounded";
  const bool aligned=balanced||mode=="caps_aligned"||mode=="caps_aligned_budget"||mode=="caps_aligned_bounded";
  const bool caps=aligned||mode=="caps"||mode=="hybrid_caps"||mode=="area_caps"||mode=="area_metric_caps"||mode=="metric_caps";
  const bool append_caps=mode=="append"||mode=="area_append"||mode=="metric_append";
  if(mode=="local"||mode=="local_budget"||mode=="hybrid"||mode=="hybrid_caps")ex::config.local_steps=5;
  if(mode=="local_budget"||mode=="hybrid"||mode=="hybrid_caps")solver.iterations=6;
  if(mode=="metric"||mode=="hybrid"||mode=="hybrid_caps")ex::config.metric_length=1.;
  if(mode=="metric_short")ex::config.metric_length=.5;
  if(mode=="metric_caps"||mode=="metric_append")ex::config.metric_length=.5;
  if(mode.rfind("area",0)==0)ex::config.sample_area=true;
  if(mode=="area_budget")solver.iterations=6;
  if(mode=="caps_aligned_budget")solver.iterations=7;
  if(mode=="area_metric"||mode=="area_metric_caps")ex::config.metric_length=.5;
  if(mode=="volume")ex::config.volume_passes=2;
  if(mode!="baseline"&&!caps&&!append_caps&&!ex::config.sample_area&&ex::config.local_steps==0&&ex::config.metric_length==0&&ex::config.volume_passes==0)throw std::runtime_error("unknown mode");
  const double original_length=seedLength(seed);const fs::path output=argv[3];fs::create_directories(output);
  std::ofstream log(output/"rows.jsonl");log<<std::setprecision(17);
  for(int repeat=-1;repeat<std::stoi(argv[10]);++repeat){ex::stats={};const auto start=c3::Clock::now();
    auto input=seed;double prefix=0,suffix=0;int retries=0;ex::requested_breaks.clear();ex::limit_end_boxes=caps;
    if(caps||append_caps){sc::Vec3 a,b=seed.front();bool first=true;const double pad=options.robot_radius+options.safety_margin+options.certificate_margin;
      for(size_t j=1;j<seed.size();){a=b;if((a-seed[j]).norm()>options.local_progress)b=a+(seed[j]-a).normalized()*options.local_progress;else b=seed[j++];
        const sc::Bounds box{(a.cwiseMin(b)-sc::Vec3::Constant(options.local_range)).cwiseMax(bounds.lower+sc::Vec3::Constant(pad)),
          (a.cwiseMax(b)+sc::Vec3::Constant(options.local_range)).cwiseMin(bounds.upper-sc::Vec3::Constant(pad))};
        if(first){ex::endpoint_boxes[0]=box;first=false;}ex::endpoint_boxes[1]=box;}}
    if(caps){const sc::Vec3 a=(seed.front()-seed[1]).normalized(),b=(seed.back()-seed[seed.size()-2]).normalized();
      prefix=extension(seed.front(),a,map,bounds,options);suffix=extension(seed.back(),b,map,bounds,options);
      if(prefix>1e-6)input.insert(input.begin(),seed.front()+prefix*a);
      if(suffix>1e-6)input.push_back(seed.back()+suffix*b);
      if(aligned){auto& knots=ex::requested_breaks;knots.push_back(0);double arc=0;
        for(double length:{prefix,original_length,suffix}){const int count=int(std::ceil(length/options.control_spacing));
          for(int j=1;j<=count;++j)knots.push_back((arc+length*j/count)/(prefix+original_length+suffix));arc+=length;}
        knots.back()=1;
        if(balanced){const double old_controls=std::ceil(original_length/options.control_spacing)+3,new_controls=knots.size()+2;
          solver.iterations=std::clamp(int(std::lround(14*old_controls/new_controls-6)),7,8);}}}
    auto trial_options=options;if(bounded)trial_options.max_refinements=0;
    auto r=c3::generateCubic(input,map,bounds,trial_options,solver);bool anchors=true;
    if(caps&&r.status==sc::Status::Success){const auto ps=patches(r.corridor);size_t unresolved=0;
      for(const auto& p:{seed.front(),seed.back()}){bool inside=false;for(const auto& patch:ps)if(patch.contains(p,unresolved)){inside=true;break;}anchors&=inside;}
      anchors&=unresolved==0;}
    const auto trial_status=r.status;const bool trial_anchors=anchors;const int trial_refinements=r.refinements;const double trial_ms=r.total_ms;
    if(caps&&(r.status!=sc::Status::Success||!anchors)){++retries;ex::requested_breaks.clear();ex::limit_end_boxes=false;
      if(balanced)solver.iterations=8;r=c3::generateCubic(seed,map,bounds,options,solver);prefix=suffix=0;anchors=true;}
    c3::Geometry preserved_core;int cap_attempts=0;
    if(append_caps&&r.status==sc::Status::Success){preserved_core=r.corridor;const auto added=sc_inflation::append(r,map,bounds,options);
      prefix=added.prefix;suffix=added.suffix;cap_attempts=added.attempts;}
    const double total=c3::elapsedMs(start);
    log<<"{\"repeat\":"<<repeat<<",\"mode\":\""<<mode<<"\",\"status\":\""<<sc::statusName(r.status)<<"\",\"wall_ms\":"<<total
       <<",\"index_ms\":"<<index_ms<<",\"newton_steps\":"<<r.optimizer.steps<<",\"termination\":\""<<r.optimizer.termination<<"\""
       <<",\"regularity_repairs\":"<<r.optimizer.regularity_repairs<<",\"regularity_backtracks\":"<<r.optimizer.regularity_backtracks
       <<",\"controls\":"<<r.optimizer.controls<<",\"constraints\":"<<r.optimizer.constraints<<",\"local_steps\":"<<ex::stats.local_steps
       <<",\"local_ms\":"<<ex::stats.local_ms<<",\"local_blocks\":"<<ex::stats.local_blocks<<",\"extra_volume_accepts\":"<<ex::stats.volume_accepts
       <<",\"extra_volume_ms\":"<<ex::stats.volume_ms<<",\"prefix\":"<<prefix<<",\"suffix\":"<<suffix<<",\"retries\":"<<retries
       <<",\"trial_status\":\""<<sc::statusName(trial_status)<<"\",\"trial_anchors\":"<<(trial_anchors?"true":"false")
       <<",\"trial_refinements\":"<<trial_refinements<<",\"trial_generation_ms\":"<<trial_ms
       <<",\"cap_attempts\":"<<cap_attempts<<",\"cover_ms\":"<<r.cover_metrics.total_ms<<",\"setup_ms\":"<<r.optimizer.setup_ms<<",\"assembly_ms\":"<<r.optimizer.assembly_ms
       <<",\"solve_ms\":"<<r.optimizer.solve_ms<<",\"line_ms\":"<<r.optimizer.line_search_ms<<",\"certificate_ms\":"<<r.optimizer.certificate_ms;
    if(r.status==sc::Status::Success){const auto certificate=c3::certify(r.corridor,r.cover);if(!certificate.safe())throw std::runtime_error("continuous certificate failed");
      const double length=original_length+prefix+suffix;const auto core=append_caps?preserved_core:restrictGeometry(r.corridor,prefix/length,(prefix+original_length)/length);
      const auto q=quality(core,original_length),full=quality(r.corridor,length);
      log<<",\"support_pass\":true,\"jacobian_pass\":true,\"anchors_pass\":"<<(anchors?"true":"false")
         <<",\"boundary_bending\":"<<q.boundary_bending<<",\"max_curvature\":"<<q.max_curvature<<",\"c2_error\":"<<full.c2_error
         <<",\"min_axis\":"<<full.min_axis<<",\"swept_volume\":"<<full.swept_volume<<",\"core_swept_volume\":"<<q.swept_volume;
      if(repeat==0){writeGeometry(r.corridor,output/"corridor.csv");writeGeometry(core,output/"core.csv");
        std::ofstream planes(output/"support_planes.csv");planes<<std::setprecision(17)<<"span,begin,end,nx,ny,nz,bound\n";
        for(const auto& p:r.cover)planes<<p.span<<','<<p.begin<<','<<p.end<<','<<p.normal[0]<<','<<p.normal[1]<<','<<p.normal[2]<<','<<p.bound<<'\n';}}
    log<<"}\n";log.flush();}
  rusage usage{};getrusage(RUSAGE_SELF,&usage);log<<"{\"max_rss_kib\":"<<usage.ru_maxrss<<"}\n";
  return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
