#include "common.hpp"
#include <cassert>
namespace ex=c3::experiment;
int main(){
  sc::Options o;o.max_radius=5;o.max_offset=5;
  ex::V5 x;x<<.1,-.2,1.2,.1,.8;const ex::M5 q=.2*ex::M5::Identity();const ex::V5 linear=ex::V5::Constant(.02);
  std::vector<ex::Row> rows;
  for(auto n:{Eigen::Vector2d(1,.2),Eigen::Vector2d(-.3,1),Eigen::Vector2d(-1,-.8)}){
    const auto j=ex::mapping(n);rows.push_back({j,sc::Vec3(4,.1,-.2),2*j.transpose()*sc::Vec3(1,-1,-1).asDiagonal()*j});}
  ex::V5 g;ex::M5 h;ex::objective(x,rows,q,linear,o,.5,.003,&g,&h);
  double gradient_error=0,hessian_error=0;
  for(int k=0;k<5;++k){auto a=x,b=x;a[k]+=1e-5;b[k]-=1e-5;ex::V5 ga,gb;ex::M5 ha,hb;
    const double fa=ex::objective(a,rows,q,linear,o,.5,.003,&ga,&ha),fb=ex::objective(b,rows,q,linear,o,.5,.003,&gb,&hb);
    gradient_error=std::max(gradient_error,std::abs((fa-fb)/2e-5-g[k]));hessian_error=std::max(hessian_error,((ga-gb)/2e-5-h.col(k)).norm());}
  assert(gradient_error<1e-7&&hessian_error<1e-7);
  const std::vector<sc::Vec3> seed{{0,0,0},{3,0,0},{6,1,0}};const sc::Bounds bounds{{-4,-4,-3},{10,6,3}};const sc::ObstacleIndex map({});
  c3::OptimizerSettings solver;ex::config={5,0,0};auto r=c3::generateCubic(seed,map,bounds,o,solver);assert(r.status==sc::Status::Success);
  assert(c3::certify(r.corridor,r.cover).safe());assert(quality(r.corridor,seedLength(seed)).c2_error<1e-7);
  auto model=c3::CubicModel::fromSeed(seed,.4,.2,1.5);c3::CubicProblem problem(model,r.cover,seedLength(seed),o,solver);
  const ex::Neighborhood neighborhood(problem);
  Eigen::VectorXd full_gradient;c3::BandedSPD full_hessian;
  assert(std::isfinite(problem.objective(model.x,.003/model.basis.count,&full_gradient,&full_hessian)));
  const Eigen::VectorXd energy_gradient=problem.quadratic.multiply(model.x)+problem.linear;
  for(int node=0;node<model.basis.count;++node){const auto local=neighborhood.rows(problem,model.x,node);
    ex::M5 block;for(int j=0;j<5;++j)for(int k=0;k<5;++k)block(j,k)=problem.quadratic.get(5*node+j,5*node+k);
    const ex::V5 value=model.x.segment<5>(5*node),linear=energy_gradient.segment<5>(5*node)-block*value;
    ex::V5 g;ex::M5 h;ex::objective(value,local,block,linear,o,model.basis.weight(node),.003/model.basis.count,&g,&h);
    assert((g-full_gradient.segment<5>(5*node)).norm()<1e-8);
    for(int j=0;j<5;++j)for(int k=0;k<5;++k)assert(std::abs(h(j,k)-full_hessian.get(5*node+j,5*node+k))<1e-8);}
  ex::config={0,0,0,true};c3::CubicProblem area_problem(model,r.cover,seedLength(seed),o,solver);
  area_problem.objective(model.x,.003/model.basis.count,&full_gradient,&full_hessian);
  for(int k=0;k<model.x.size();k+=7){auto a=model.x,b=model.x;a[k]+=1e-5;b[k]-=1e-5;
    Eigen::VectorXd ga,gb;area_problem.objective(a,.003/model.basis.count,&ga,nullptr);area_problem.objective(b,.003/model.basis.count,&gb,nullptr);
    const double derivative=(area_problem.objective(a,.003/model.basis.count)-area_problem.objective(b,.003/model.basis.count))/2e-5;
    assert(std::abs(derivative-full_gradient[k])<1e-6);
    for(int j=0;j<model.x.size();++j)assert(std::abs((ga[j]-gb[j])/2e-5-full_hessian.get(j,k))<1e-6);}
  Eigen::VectorXd direction=Eigen::VectorXd::LinSpaced(model.x.size(),-.001,.001);
  const auto line=area_problem.prepareLine(model.x,direction,.003/model.basis.count);
  for(double alpha:{.1,.5,.9}){const double actual=area_problem.objective(model.x+alpha*direction,.003/model.basis.count)-area_problem.objective(model.x,.003/model.basis.count);
    assert(std::abs(actual-line.delta(alpha))<1e-9);}
  const auto sub=restrictGeometry(r.corridor,.17,.83);
  for(double u:{0.,.1,.5,.9,1.}){const auto a=sub.section(u),b=r.corridor.section(.17+.66*u);assert((a.center-b.center).norm()<1e-9);assert((a.shape-b.shape).norm()<1e-9);}
  std::cout<<"gradient_error="<<gradient_error<<" hessian_error="<<hessian_error<<" C2 and continuous certificates PASS\n";
}
