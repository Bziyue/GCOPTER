#!/usr/bin/env python3
"""Offline paired QMC; excludes all geometry/query measurements from timings."""
import argparse,json,os,resource,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('report');p.add_argument('--build',default='.scratch/inflation');p.add_argument('--modes',default='all');p.add_argument('--cases',default='all');p.add_argument('--samples',type=int,default=65536);a=p.parse_args()
repo=Path(__file__).resolve().parents[3];os.chdir(repo)
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3));os.sched_setaffinity(0,{2})
directory=Path(a.report);summary=json.loads((directory/'summary.json').read_text());manifest=json.loads((directory/'manifest.json').read_text());cases={r['case']:r for r in manifest['cases']}
baseline={r['case']:r for r in summary if r['mode']=='baseline'}
selected=None if a.modes=='all' else set(a.modes.split(','));binary=Path(a.build).resolve()/'measure'
selected_cases=None if a.cases=='all' else set(map(int,a.cases.split(',')))
for r in summary:
    if selected_cases is not None and r['case'] not in selected_cases:continue
    if r['mode']=='baseline' or not r['success'] or (selected is not None and r['mode'] not in selected):continue
    base=baseline[r['case']]
    if not base['success']:continue
    target=Path(r['output']);reference=Path(base['output'])/'corridor.csv';seed=cases[r['case']]['seed']
    for label,file in [('union','corridor.csv'),('core_union','core.csv')]:
        candidate=target/file
        if label=='core_union' and candidate.read_bytes()==(target/'corridor.csv').read_bytes():r[label]=r['union'];continue
        if label=='core_union' and candidate.read_bytes()==reference.read_bytes():
            r[label]=dict(baseline=r['union']['baseline'],candidate=r['union']['baseline'],paired_delta=0.,paired_ci95=0.,samples=r['union']['samples'],unresolved=0,exact_geometry=True);continue
        result=json.loads(subprocess.check_output([str(binary),str(reference),str(candidate),seed,str(a.samples)],text=True,timeout=180))
        assert result['unresolved']==0;r[label]=result;(target/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    if r.get('prefix',0)+r.get('suffix',0)>0:
        if r['core_union'].get('exact_geometry'):r['cap_increment']=r['union']
        else:
            result=json.loads(subprocess.check_output([str(binary),str(target/'core.csv'),str(target/'corridor.csv'),seed,str(a.samples)],text=True,timeout=180))
            assert result['unresolved']==0;r['cap_increment']=result
            (target/'cap_increment.json').write_text(json.dumps(result,indent=2)+'\n')
    (directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(r['case'],r['mode'],'union %',round(100*r['union']['paired_delta']/r['union']['baseline'],3),'CI %',round(100*r['union']['paired_ci95']/r['union']['baseline'],3),'core %',round(100*r['core_union']['paired_delta']/r['core_union']['baseline'],3),flush=True)
