// SPDX-License-Identifier: MIT
#include "cubic_optimizer.hpp"
#include "cubic_certificates.hpp"
#include <Eigen/Eigenvalues>
#include <Eigen/SparseCholesky>
#include <Eigen/QR>
#include <chrono>
#include <map>
namespace gcopter::direct::native {
using Clock=std::chrono::steady_clock;
static double ms(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
static Eigen::Matrix2d matrix(const Eigen::VectorXd& x,int i) {
  Eigen::Matrix2d s;s<<x[5*i+2],x[5*i+3],x[5*i+3],x[5*i+4];return s;
}
Eigen::Matrix<double,9,5> CubicModel::jacobian(int i)const {
  Eigen::Matrix<double,9,5> j=Eigen::Matrix<double,9,5>::Zero();
  j.topLeftCorner<3,2>()=frames[i];
  j.block<3,1>(3,2)=frames[i].col(0);j.block<3,1>(3,3)=frames[i].col(1);
  j.block<3,1>(6,3)=frames[i].col(0);j.block<3,1>(6,4)=frames[i].col(1);return j;
}
Geometry CubicModel::geometry(const Eigen::VectorXd& values)const {
  std::vector<V9> controls(basis.count);
  for(int i=0;i<basis.count;++i)controls[i]=pack(reference[i]+frames[i]*values.segment<2>(5*i),frames[i]*matrix(values,i));
  return Geometry::fromCubic(basis,controls);
}
CubicModel CubicModel::project(const Geometry& natural) {
  CubicModel out(natural.breaks);const int count=out.basis.count;
  std::vector<Eigen::Triplet<double>> entries;
  Eigen::Matrix<double,Eigen::Dynamic,9> rhs=Eigen::Matrix<double,Eigen::Dynamic,9>::Zero(count,9);
  for(int i=0;i<int(natural.pieces());++i) {
    const auto& e=out.basis.spans[i].extraction;
    for(int j=0;j<4;++j)for(int k=0;k<4;++k) {
      rhs.row(i+k)+=e(j,k)*natural.controls[4*i+j].transpose();
      for(int l=0;l<4;++l)entries.emplace_back(i+k,i+l,e(j,k)*e(j,l));
    }
  }
  Eigen::SparseMatrix<double> a(count,count);a.setFromTriplets(entries.begin(),entries.end());
  Eigen::SimplicialLDLT<Eigen::SparseMatrix<double>> solver(a);
  const Eigen::Matrix<double,Eigen::Dynamic,9> values=solver.solve(rhs);
  out.x.setZero();
  for(int i=0;i<count;++i) {
    const V9 y=values.row(i);const Mat32 m=shape(y);
    Eigen::SelfAdjointEigenSolver<Eigen::Matrix2d> e(m.transpose()*m);
    if(e.eigenvalues()[0]<1e-14)throw std::runtime_error("rank-deficient projected cubic control");
    const Eigen::Matrix2d s=e.eigenvectors()*e.eigenvalues().cwiseSqrt().asDiagonal()*e.eigenvectors().transpose();
    out.reference[i]=y.head<3>();out.frames[i]=m*s.inverse();
    out.x.segment<3>(5*i+2)<<s(0,0),s(0,1),s(1,1);
  }
  return out;
}
CubicModel CubicModel::fromSeed(const std::vector<Vec3>& seed,double spacing,double radius,double smoothing) {
  std::vector<double> arc(seed.size(),0);std::vector<Vec3> moment(seed.size(),Vec3::Zero());
  for(size_t i=1;i<seed.size();++i){arc[i]=arc[i-1]+(seed[i]-seed[i-1]).norm();moment[i]=moment[i-1]+.5*(arc[i]+arc[i-1])*(seed[i]-seed[i-1]);}
  const double length=arc.back();const int segments=std::max(1,int(std::ceil(length/spacing)));
  std::vector<double> breaks;for(int i=0;i<=segments;++i)breaks.push_back(double(i)/segments);
  CubicModel out(breaks);out.x.setZero();
  auto segment=[&](double s){return std::clamp(int(std::upper_bound(arc.begin(),arc.end(),s)-arc.begin())-1,0,int(seed.size())-2);};
  auto integral=[&](double s) {
    s=std::clamp(s,0.,length);const int k=segment(s);
    const Vec3 displacement=(s-arc[k])/(arc[k+1]-arc[k])*(seed[k+1]-seed[k]);
    return std::make_pair(Vec3(seed[k]-seed[0]+displacement),Vec3(moment[k]+.5*(s+arc[k])*displacement));
  };
  Vec3 previous=Vec3::Zero(),axis=Vec3::Zero();
  for(int i=0;i<out.basis.count;++i) {
    const double s=length*out.basis.greville(i);const int k=segment(s);
    out.reference[i]=seed[k]+(s-arc[k])/(arc[k+1]-arc[k])*(seed[k+1]-seed[k]);
    Vec3 tangent=(seed[k+1]-seed[k]).normalized();
    if(smoothing>0) {
      const auto a=integral(s-smoothing),b=integral(s),c=integral(s+smoothing);
      const Vec3 average=(1-s/smoothing)*(b.first-a.first)+(b.second-a.second)/smoothing+
                         (1+s/smoothing)*(c.first-b.first)-(c.second-b.second)/smoothing;
      if(average.dot(tangent)>.15*average.norm())tangent=average.normalized();
    }
    if(!i)axis=tangent.unitOrthogonal();else {axis=Eigen::Quaterniond::FromTwoVectors(previous,tangent)*axis;axis-=tangent*tangent.dot(axis);axis.normalize();}
    out.frames[i].col(0)=axis;out.frames[i].col(1)=tangent.cross(axis);previous=tangent;
    out.x[5*i+2]=out.x[5*i+4]=radius;
  }
  return out;
}
CubicProblem::CubicProblem(const CubicModel& m,const std::vector<detail::SupportPlane>& cover,
                           double length,const Options& o,const OptimizerSettings& s)
    :model(m),options(o),settings(s),quadratic(5*m.basis.count,19),linear(Eigen::VectorXd::Zero(5*m.basis.count)) {
  // On the same parameter interval, equal normals only need the tightest
  // bound. World/local-box duplicates otherwise add both work and barrier bias.
  std::map<std::tuple<int,double,double,double,double,double>,detail::SupportPlane> unique;
  for(const auto& p:cover) {
    const auto key=std::make_tuple(p.span,p.begin,p.end,p.normal[0],p.normal[1],p.normal[2]);
    auto found=unique.find(key);
    if(found==unique.end()||p.bound<found->second.bound)unique[key]=p;
  }
  for(const auto& entry:unique) {
    const auto& plane=entry.second;
    const auto& span=m.basis.spans[plane.span];
    Curve<3,Eigen::Vector4d> basis;
    for(int j=0;j<4;++j)basis[j]=span.extraction.row(j);
    basis=restrictCurve<3>(basis,plane.begin,plane.end);
    for(int j=0;j<4;++j) {
      Cut c;c.first=5*span.ids[0];c.map.setZero();c.bound=plane.bound;
      for(int k=0;k<4;++k) {
        const int id=span.ids[k];const Eigen::Vector2d n=basis[j][k]*m.frames[id].transpose()*plane.normal;
        c.bound-=basis[j][k]*m.reference[id].dot(plane.normal);
        c.map.block<1,2>(0,5*k)=n.transpose();
        c.map(1,5*k+2)=n[0];c.map(1,5*k+3)=n[1];c.map(2,5*k+3)=n[0];c.map(2,5*k+4)=n[1];
      }
      // Skip constraints which are identically constant (e.g. a straight end cap).
      if(c.map.squaredNorm()<1e-25){if(c.bound < -1e-9)throw std::runtime_error("inconsistent constant support plane");continue;}
      cuts.push_back(c);
    }
  }
  // Local convex progress cones are added only after a full-disk failure.
  // They use fixed normals and a degree-two derivative hull. The nonlinear
  // full-disk certificate remains the acceptance test after every repair.
  const auto initial=m.geometry();
  for(int span:settings.progress_spans)for(double t:{0.,.5,1.}) {
    const double u=m.basis.breaks[span]+t*(m.basis.breaks[span+1]-m.basis.breaks[span]);
    const auto section=initial.section(u);
    const Vec3 normal=section.shape.col(0).cross(section.shape.col(1)).normalized();
    const auto& e=m.basis.spans[span].extraction;
    Curve<2,Eigen::Vector4d> derivative;
    for(int j=0;j<3;++j)derivative[j]=3*(e.row(j+1)-e.row(j));
    const auto halves=split<2>(derivative);
    for(const auto& part:{halves.first,halves.second})for(const auto& weight:part) {
      Cut c;c.first=5*span;c.map.setZero();c.bound=-1e-5*length*(m.basis.breaks[span+1]-m.basis.breaks[span]);
      for(int k=0;k<4;++k) {
        const Eigen::Vector2d v=weight[k]*m.frames[span+k].transpose()*normal;
        c.bound+=weight[k]*m.reference[span+k].dot(normal);
        c.map.block<1,2>(0,5*k)=-v.transpose();
        c.map(1,5*k+2)=v[0];c.map(1,5*k+3)=v[1];c.map(2,5*k+3)=v[0];c.map(2,5*k+4)=v[1];
      }
      const Vec3 value=c.map*m.x.segment<20>(c.first);
      if(c.bound-value[0]>value.tail<2>().norm()+1e-9 && c.map.squaredNorm()>1e-25)cuts.push_back(c);
    }
  }
  // Exact two-point Gauss integration of squared cubic second derivatives.
  for(int i=0;i<int(m.basis.spans.size());++i) {
    const double h=m.basis.breaks[i+1]-m.basis.breaks[i];
    for(double t:{.5-.5/std::sqrt(3.),.5+.5/std::sqrt(3.)}) {
      const auto basis=m.basis.jet(i,m.basis.breaks[i]+h*t);
      Eigen::Matrix<double,9,20> map;V9 reference=V9::Zero();
      for(int k=0;k<4;++k) {
        const double d=basis(2,k)/(length*length);
        map.middleCols<5>(5*k)=d*m.jacobian(i+k);reference.head<3>()+=d*m.reference[i+k];
      }
      const double wc=std::sqrt(settings.center_energy*.5*h*length),wm=std::sqrt(settings.shape_energy*.5*h*length);
      map.topRows<3>()*=wc;map.bottomRows<6>()*=wm;reference.head<3>()*=wc;
      const Eigen::Matrix<double,20,20> gram=2*map.transpose()*map;
      linear.segment<20>(5*i)+=2*map.transpose()*reference;
      for(int a=0;a<20;++a)for(int b=0;b<=a;++b)quadratic.add(5*i+a,5*i+b,gram(a,b));
    }
  }
  for(int i=0;i<m.basis.count;++i)for(int k=0;k<2;++k)quadratic.add(5*i+k,5*i+k,2*settings.offset_weight*m.basis.weight(i));
  if(settings.natural_endpoints) {
    Eigen::MatrixXd a=Eigen::MatrixXd::Zero(18,5*m.basis.count);
    for(int end=0;end<2;++end) {
      const int span=end?int(m.basis.spans.size())-1:0;
      const auto b=m.basis.jet(span,end?1.:0.);
      for(int k=0;k<4;++k)a.block<9,5>(9*end,5*(span+k))=b(2,k)*m.jacobian(span+k)/(length*length);
    }
    for(int id:{0,1,5*(m.basis.count-1),5*(m.basis.count-1)+1})a.col(id).setZero();
    for(int i=0;i<a.rows();++i){const double n=a.row(i).norm();if(n>0)a.row(i)/=n;}
    Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(a.transpose());qr.setThreshold(1e-9);
    equalities.resize(qr.rank(),a.cols());
    for(int i=0;i<qr.rank();++i)equalities.row(i)=a.row(qr.colsPermutation().indices()[i]);
  }
}
double CubicProblem::objective(const Eigen::VectorXd& x,double mu,Eigen::VectorXd* g,BandedSPD* h)const {
  const bool derivatives=g;
  const auto qx=quadratic.multiply(x);
  double cost=.5*x.dot(qx)+linear.dot(x);
  if(derivatives){*g=qx+linear;*h=quadratic;}
  auto logdet=[&](int i,const Eigen::Matrix2d& p,double weight,double sign) {
    const double det=p.determinant();if(p(0,0)<=0 || det<=0)return false;
    cost-=weight*std::log(det);
    if(derivatives) {
      const double a=p(1,1)/det,b=-p(0,1)/det,c=p(0,0)/det;
      g->segment<3>(5*i+2)-=weight*sign*Vec3(a,2*b,c);
      Eigen::Matrix3d v;v<<a*a,2*a*b,b*b,2*a*b,2*(a*c+b*b),2*b*c,b*b,2*b*c,c*c;
      for(int j=0;j<3;++j)for(int k=0;k<=j;++k)h->add(5*i+2+j,5*i+2+k,weight*v(j,k));
    }
    return true;
  };
  for(int i=0;i<model.basis.count;++i) {
    const auto s=matrix(x,i);
    if(!logdet(i,s,model.basis.weight(i),1) ||
       !logdet(i,s-options.min_radius*Eigen::Matrix2d::Identity(),mu,1) ||
       !logdet(i,options.max_radius*Eigen::Matrix2d::Identity()-s,mu,-1))return INFINITY;
    const Eigen::Vector2d d=x.segment<2>(5*i);const double gap=options.max_offset*options.max_offset-d.squaredNorm();
    if(gap<=0)return INFINITY;
    cost-=mu*std::log(gap);
    if(derivatives) {
      g->segment<2>(5*i)+=2*mu/gap*d;
      const Eigen::Matrix2d v=2*mu/gap*Eigen::Matrix2d::Identity()+4*mu/(gap*gap)*d*d.transpose();
      for(int j=0;j<2;++j)for(int k=0;k<=j;++k)h->add(5*i+j,5*i+k,v(j,k));
    }
  }
  for(const auto& c:cuts) {
    Eigen::Vector3d v=c.map*x.segment<20>(c.first);v[0]=c.bound-v[0];
    const double slack=v[0]*v[0]-v.tail<2>().squaredNorm();
    if(v[0]<=0 || slack<=0)return INFINITY;
    cost-=mu*std::log(slack);
    if(derivatives) {
      const Eigen::Matrix<double,20,1> ds=-2*c.map.transpose()*v;
      g->segment<20>(c.first)-=mu/slack*ds;
      const double first=mu/slack,second=first/slack;
      Eigen::Matrix<double,20,20> local=second*ds*ds.transpose();
      local.noalias()+=2*first*c.map.bottomRows<2>().transpose()*c.map.bottomRows<2>();
      local.noalias()-=2*first*c.map.row(0).transpose()*c.map.row(0);
      for(int j=0;j<20;++j)for(int k=0;k<=j;++k)h->add(c.first+j,c.first+k,local(j,k));
    }
  }
  return cost;
}
void CubicProblem::checkDerivatives(const Eigen::VectorXd& x,OptimizerMetrics& metrics)const {
  const double mu=.003/model.basis.count;
  Eigen::VectorXd g;BandedSPD h;const double f=objective(x,mu,&g,&h);(void)f;
  for(int trial=0;trial<8;++trial) {
    Eigen::VectorXd v(x.size());for(int j=0;j<v.size();++j)v[j]=std::sin((j+1)*(trial+1)*.381);
    v.normalize();double step=1e-6;
    while(step>1e-12 && (!std::isfinite(objective(x+step*v,mu))||!std::isfinite(objective(x-step*v,mu))))step*=.1;
    const double fd=(objective(x+step*v,mu)-objective(x-step*v,mu))/(2*step);
    metrics.gradient_error=std::max(metrics.gradient_error,std::abs(fd-g.dot(v))/std::max({1.,std::abs(fd),std::abs(g.dot(v))}));
    Eigen::VectorXd gp,gm;BandedSPD scratch;
    objective(x+step*v,mu,&gp,&scratch);objective(x-step*v,mu,&gm,&scratch);
    const Eigen::VectorXd hv=h.multiply(v),num=(gp-gm)/(2*step);
    metrics.hessian_error=std::max(metrics.hessian_error,(num-hv).norm()/std::max({1.,num.norm(),hv.norm()}));
  }
}
void CubicProblem::optimize(Eigen::VectorXd& x,OptimizerMetrics& metrics,const std::function<void()>& stop)const {
  metrics.controls=model.basis.count;metrics.variables=x.size()-4;metrics.constraints=cuts.size();metrics.equality_rank=equalities.rows();
  metrics.hessian_nonzero=x.size()*20-190;
  if(settings.check_gradients)checkDerivatives(x,metrics);
  for(double barrier:{.003,.0001,.00001}) {
    const double mu=barrier/model.basis.count;
    bool converged=false;
    for(int it=0;it<settings.iterations;++it) {
      stop();auto timer=Clock::now();Eigen::VectorXd g;BandedSPD h;
      const double f=objective(x,mu,&g,&h);metrics.assembly_ms+=ms(timer);
      if(!std::isfinite(f))throw std::runtime_error("cubic optimizer initial point is infeasible");
      for(int id:{0,1,int(x.size())-5,int(x.size())-4}){g[id]=0;h.fix(id);}
      timer=Clock::now();double damping=0;
      while(!h.factor(damping)){damping=damping==0?1e-8:damping*10;++metrics.damping_retries;if(damping>1e6)throw std::runtime_error("cubic band factorization failed");}
      Eigen::VectorXd step=h.solve(-g);
      if(equalities.rows()) {
        Eigen::MatrixXd solve(x.size(),equalities.rows());
        for(int j=0;j<equalities.rows();++j)solve.col(j)=h.solve(equalities.row(j).transpose());
        const Eigen::MatrixXd schur=equalities*solve;
        step-=solve*schur.ldlt().solve(equalities*step);
      }
      metrics.solve_ms+=ms(timer);
      const double decrement=-g.dot(step);
      if(decrement<settings.gradient_tolerance){converged=true;break;}
      timer=Clock::now();double alpha=1;Eigen::VectorXd next;
      for(;;) {
        next=x+alpha*step;
        if(objective(next,mu)<=f-1e-4*alpha*decrement)break;
        alpha*=.5;++metrics.backtracks;
        if(alpha<1e-12){metrics.termination="line_search_stalled";return;}
      }
      metrics.line_search_ms+=ms(timer);
      x=std::move(next);++metrics.steps;
    }
    metrics.termination=converged?"newton_decrement":"iteration_limit";
  }
}
}
