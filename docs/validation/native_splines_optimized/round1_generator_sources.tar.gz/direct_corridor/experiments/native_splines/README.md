# Native spline experiments

Research branch based on `ros2@15c70cd`. Production generation and ROS defaults
remain H5-S. The report, figures, full measurement sequences and compressed
geometry/trajectory coefficients are in
[`docs/原生三次与最小jerk走廊实验.md`](../../../docs/原生三次与最小jerk走廊实验.md).

Implemented: exact nonuniform cubic extraction, degree-aware affine-disc
geometry, natural cubic and free-endpoint minimum-jerk diagnostics, continuous
sphere/support and full-disk Jacobian certificates, native and H5-projected
cubic initialization, five-variable control-point optimization, band Cholesky,
natural-endpoint projection ablation, and common-backend trajectory replay.

The seven frozen cases are a development experiment. Q5-C joint optimization,
derivative elimination, native initialization with natural endpoints, full
parameter/equal-variable scans and held-out scene evaluation are not yet
implemented. `Q5-T` and `H5-C3-T` currently mean global jet-fraction controls;
`H5-Z-fixed` means zeroing shape jets at the current H5-S nodal values.

```bash
cd /home/zdp/ForCodex/GCOPTER
python3 direct_corridor/experiments/native_splines/freeze.py
cmake -S direct_corridor/experiments/native_splines \
  -B .scratch/native_splines/build -DCMAKE_BUILD_TYPE=Release
cmake --build .scratch/native_splines/build -j1
ctest --test-dir .scratch/native_splines/build --output-on-failure -j1
python3 direct_corridor/experiments/native_splines/run.py --native \
  --output .scratch/native_splines/final
```

For trajectory replay, reconfigure with `-DNATIVE_SPLINE_TRAJECTORY=ON` and the
installed OMPL prefix if needed, build `native_trajectory_comparison` serially,
then run `trajectory.py`. It verifies frozen geometry against the map, elevates
cubics exactly, and uses the existing optimizer and identical initialization.
Primary timing has profiling off; `--profile` enables a separate diagnostic run.
The replay's `corridor_ms` is reading/audit/adaptation time, not generation time.

`compare.py` archives measurements and draws figures using NumPy/Matplotlib.
`independent_audit.py` uses NumPy and SciPy for an additional nearest-sphere
sampling audit. The continuous certificates remain the output acceptance test.
`native_volume_refine` increases QMC samples without regenerating a corridor.

The CSV v3 header begins `degree,u0,u1` followed by nine world-space geometric
channels. There are exactly four or six controls per interval. The legacy v2
production interface remains unchanged; `GeometryAccess` supplies an isolated
exact-elevation adapter for this experiment.
