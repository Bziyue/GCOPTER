// SPDX-License-Identifier: MIT
#include "cubic_generator.hpp"
#include <chrono>
namespace gcopter::direct::native {
using Clock=std::chrono::steady_clock;
static double ms(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
CubicResult generateCubic(const std::vector<Vec3>& input_seed,const ObstacleIndex& index,
                          const Bounds& bounds,const Options& o,const OptimizerSettings& solver,
                          const Geometry* projected_reference) {
  CubicResult result;const auto start=Clock::now();
  const std::function<void()> stop=[&]{if(ms(start)>o.budget_ms)throw Failure{Status::Timeout,"cubic generation deadline"};};
  // Validate at this boundary; the model, objective and Newton loop consume
  // the resulting finite, nonduplicate seed without repeating these checks.
  if(!bounds.lower.allFinite()||!bounds.upper.allFinite()||!(bounds.upper.array()>bounds.lower.array()).all()||
     !(o.control_spacing>0)||!(o.min_radius>0)||!(o.max_radius>o.min_radius)||!(o.local_range>0)||!(o.local_progress>0)||
     !(o.budget_ms>0)||o.max_refinements<0||o.max_refinements>20) {
    result.status="INVALID_INPUT";result.message="invalid cubic generator options/bounds";return result;
  }
  std::vector<Vec3> seed;
  for(const auto& p:input_seed) {
    if(!p.allFinite()){result.status="INVALID_INPUT";return result;}
    if(seed.empty()||(p-seed.back()).norm()>1e-10)seed.push_back(p);
  }
  double length=0;for(size_t i=1;i<seed.size();++i)length+=(seed[i]-seed[i-1]).norm();
  if(seed.size()<2 || length<=0){result.status="INVALID_INPUT";return result;}
  const int refinements=projected_reference?0:o.max_refinements;
  try {
    const double pad=o.robot_radius+o.safety_margin;
    for(size_t i=1;i<seed.size();++i) {
      const Vec3 a=seed[i-1],b=seed[i],d=b-a;
      std::vector<int> ids;index.query(a.cwiseMin(b)-Vec3::Constant(pad),a.cwiseMax(b)+Vec3::Constant(pad),ids);
      for(int id:ids){const auto& sphere=index.obstacles()[id];const double t=std::clamp((sphere.center-a).dot(d)/d.squaredNorm(),0.,1.);
        if((sphere.center-a-t*d).norm()<=sphere.radius+pad)throw Failure{Status::SeedCollision,"seed intersects an inflated obstacle"};}
    }
    for(int refinement=0;refinement<=refinements;++refinement) {
      result.refinements=refinement;stop();auto timer=Clock::now();
      if(!projected_reference && std::ceil(length/std::ldexp(o.control_spacing,-refinement))+3>o.max_controls)
        throw Failure{Status::Capacity,"cubic control capacity"};
      CubicModel model=projected_reference?CubicModel::project(naturalCubic(*projected_reference)):
        CubicModel::fromSeed(seed,std::ldexp(o.control_spacing,-refinement),o.min_radius*1.1,o.frame_smoothing);
      result.initialization_ms+=ms(timer);
      if(size_t(model.basis.count)>o.max_controls)throw Failure{Status::Capacity,"cubic control capacity"};
      QueryCache cache;std::vector<detail::SupportPlane> cover;bool initialized=false;
      const auto original=model.x;
      for(int attempt=0;attempt<(projected_reference?20:1);++attempt) {
        ++result.initialization_attempts;stop();
        if(attempt) {
          const double fraction=std::pow(.8,attempt);
          for(int i=0;i<model.basis.count;++i)model.x.segment<3>(5*i+2)=fraction*original.segment<3>(5*i+2);
          result.optimizer.initial_scale=fraction;
        }
        try {
          const auto g=model.geometry();
          cover=mapCover(g,seed,index,bounds,o,cache,result.cover_metrics,stop);
          if(!certify(g,cover).safe())throw Failure{Status::VerificationFailed,"initial full-disk certificate"};
          CubicProblem test(model,cover,length,o,solver);
          if(!std::isfinite(test.objective(model.x,.003/model.basis.count)))throw Failure{Status::InsufficientClearance,"initial SOC interior"};
          initialized=true;break;
        }catch(const Failure& error){result.message=error.message;}
      }
      if(!initialized)continue;
      for(int iteration=0;iteration<o.inflation_iterations;++iteration) {
        stop();
        if(iteration)cover=mapCover(model.geometry(),seed,index,bounds,o,cache,result.cover_metrics,stop);
        timer=Clock::now();
        auto current=solver;if(!iteration)current.iterations=o.initial_iterations;
        current.check_gradients=solver.check_gradients&&!iteration;
        CubicProblem problem(model,cover,length,o,current);result.optimizer.setup_ms+=ms(timer);
        const Eigen::VectorXd initial=model.x;
        auto candidate=model.x;
        problem.optimize(candidate,result.optimizer,stop);
        for(int repair=0;repair<3;++repair) {
          const auto g=model.geometry(candidate);std::vector<int> failed;
          for(int i=0;i<int(g.pieces());++i){Certificate c;if(!jacobianCertificate<3>(g.curve<3>(i),c))failed.push_back(i);}
          if(failed.empty())break;
          current.progress_spans.insert(current.progress_spans.end(),failed.begin(),failed.end());
          std::sort(current.progress_spans.begin(),current.progress_spans.end());
          current.progress_spans.erase(std::unique(current.progress_spans.begin(),current.progress_spans.end()),current.progress_spans.end());
          current.check_gradients=false;++result.optimizer.regularity_repairs;
          timer=Clock::now();CubicProblem repaired(model,cover,length,o,current);result.optimizer.setup_ms+=ms(timer);
          candidate=initial;repaired.optimize(candidate,result.optimizer,stop);
        }
        timer=Clock::now();
        for(int backtrack=0;;++backtrack) {
          model.x=initial+std::ldexp(1.,-backtrack)*(candidate-initial);
          if(certify(model.geometry(),cover).safe())break;
          ++result.optimizer.regularity_backtracks;
          if(backtrack==32){model.x=initial;break;}
        }
        result.optimizer.certificate_ms+=ms(timer);
      }
      timer=Clock::now();auto g=model.geometry();const auto final=certify(g,cover);
      result.verification_ms+=ms(timer);
      if(!final.safe())throw Failure{Status::VerificationFailed,"final cubic support/Jacobian audit"};
      if(solver.natural_endpoints) {
        double residual=0;
        for(double u:{0.,1.}){const auto s=g.section(u);residual=std::max(residual,pack(s.second,s.shape_second).norm()/(length*length));}
        if(residual>1e-7)throw Failure{Status::VerificationFailed,"natural endpoint residual"};
      }
      result.corridor=std::move(g);result.cover=std::move(cover);result.status="SUCCESS";result.message.clear();break;
    }
    if(result.status!="SUCCESS")result.status="INITIALIZATION_FAILED";
  }catch(const Failure& error){result.status=statusName(error.status);result.message=error.message;}
   catch(const std::exception& error){result.status="NUMERICAL_FAILURE";result.message=error.what();}
  result.total_ms=ms(start);return result;
}
}
